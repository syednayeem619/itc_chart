import React, { Suspense, lazy } from 'react';
import { Loader2 } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';

// Lazy load below-the-fold components to reduce initial bundle size
const FAQ = lazy(() => import('./components/FAQ'));
const Benefits = lazy(() => import('./components/Benefits'));
const MasterCourse = lazy(() => import('./components/MasterCourse'));
const ROICalculator = lazy(() => import('./components/ROICalculator'));
const WhatsAppVerifier = lazy(() => import('./components/WhatsAppVerifier'));
const Testimonials = lazy(() => import('./components/Testimonials'));
const TelegramCommunity = lazy(() => import('./components/TelegramCommunity'));
const TradingQuiz = lazy(() => import('./components/TradingQuiz'));
const Footer = lazy(() => import('./components/Footer'));
const ChatBot = lazy(() => import('./components/ChatBot'));
const TradingQuotesSlider = lazy(() => import('./components/TradingQuotesSlider'));
const ScrollToTop = lazy(() => import('./components/ScrollToTop'));

// Loading Fallback to prevent layout shifts
const SectionLoader = () => (
  <div className="w-full h-64 flex items-center justify-center bg-slate-50 dark:bg-slate-950 transition-colors">
    <Loader2 className="w-8 h-8 animate-spin text-royal-500" />
  </div>
);

const App: React.FC = () => {
  return (
    <main className="bg-slate-50 dark:bg-slate-950 min-h-screen text-slate-900 dark:text-slate-50 font-sans selection:bg-royal-200 selection:text-royal-900 transition-colors duration-300">
      <Navbar />
      <Hero />
      
      <Suspense fallback={<div className="h-40 bg-slate-50 dark:bg-slate-950" />}>
        <TradingQuotesSlider />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <FAQ />
      </Suspense>
      
      <Suspense fallback={<SectionLoader />}>
        <Benefits />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <MasterCourse />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <ROICalculator />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <WhatsAppVerifier />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <Testimonials />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <TelegramCommunity />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <TradingQuiz />
      </Suspense>
      
      {/* Final CTA Section */}
      <section className="py-20 bg-gradient-to-br from-royal-900 to-slate-900 text-center px-4 relative overflow-hidden group">
         {/* Background pattern */}
         <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] group-hover:scale-105 transition-transform duration-[20s]"></div>
         
         <div className="relative z-10">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-4 tracking-tight">Ready to Trade Like the Institutions?</h2>
            <p className="text-slate-400 mb-8 max-w-xl mx-auto">Join thousands of traders mastering the ITC strategy. Stop guessing and start trading with an edge.</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
                <a href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20am%20interested%20in%20the%20ITC%20Master%20Course" target="_blank" rel="noreferrer" className="px-8 py-4 bg-gradient-to-r from-turquoise-500 to-green-500 text-white font-bold rounded-lg shadow-lg hover:shadow-[0_0_35px_rgba(20,184,166,0.5)] hover:scale-105 hover:-translate-y-1 transition-all duration-300 active:scale-95 cubic-bezier(0.4, 0, 0.2, 1) will-change-transform">
                    Enroll Now - ₹4,999
                </a>
                <a href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20have%20a%20query%20regarding%20the%20course" target="_blank" rel="noreferrer" className="px-8 py-4 bg-white/10 border border-white/20 text-white font-bold rounded-lg hover:bg-white/20 hover:border-white/40 hover:-translate-y-1 hover:scale-105 transition-all duration-300 active:scale-95 backdrop-blur-sm cubic-bezier(0.4, 0, 0.2, 1) hover:shadow-lg will-change-transform">
                    Contact Admin on Telegram
                </a>
            </div>
         </div>
      </section>

      <Suspense fallback={<div className="h-20 bg-slate-950" />}>
        <Footer />
      </Suspense>
      
      <Suspense fallback={null}>
        <ChatBot />
      </Suspense>

      <Suspense fallback={null}>
        <ScrollToTop />
      </Suspense>
    </main>
  );
};

export default App;