
import React from 'react';
import { BENEFITS } from '../constants';

const Benefits: React.FC = () => {
  return (
    <section id="benefits" className="py-12 bg-slate-50 dark:bg-slate-950 relative transition-colors duration-500 cubic-bezier(0.4, 0, 0.2, 1)">
      {/* Section Background Decor */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-slate-200 dark:via-slate-800 to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-10">
          <div className="inline-block mb-3">
             <span className="bg-royal-50 dark:bg-royal-900/30 text-royal-700 dark:text-royal-300 border border-royal-100 dark:border-royal-800 text-[10px] font-bold uppercase tracking-[0.2em] px-4 py-1.5 rounded-full hover:shadow-[0_4px_12px_rgba(14,165,233,0.15)] hover:-translate-y-0.5 hover:scale-105 transition-all duration-300 cursor-default will-change-transform">
                Why Choose ITC
             </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 dark:text-white mb-4 tracking-tight">
            Institutional <span className="text-transparent bg-clip-text bg-gradient-to-r from-royal-600 to-turquoise-500 dark:from-royal-400 dark:to-turquoise-400 animate-text-shimmer bg-[200%_auto]">Edge</span>
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-base max-w-2xl mx-auto leading-relaxed font-light">
            Our strategies are built on institutional logic, not retail myths. 
            Proven methods to navigate NSE & BSE with absolute confidence.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {BENEFITS.map((benefit) => (
            <div 
              key={benefit.id}
              className="group bg-white dark:bg-slate-900 p-4 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 transition-all duration-400 cubic-bezier(0.34, 1.56, 0.64, 1) hover:-translate-y-1 hover:scale-[1.01] hover:shadow-[0_15px_30px_-10px_rgba(14,165,233,0.15)] dark:hover:shadow-[0_15px_30px_-10px_rgba(14,165,233,0.15)] hover:border-royal-200/60 dark:hover:border-royal-700/60 relative overflow-hidden will-change-transform backdrop-blur-sm flex items-start gap-4"
            >
              {/* Subtle Gradient Background on Hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${benefit.colorGradient} dark:from-slate-800 dark:to-slate-900 opacity-0 group-hover:opacity-10 dark:group-hover:opacity-60 transition-opacity duration-500 ease-in-out pointer-events-none`}></div>
              
              {/* Icon Section - Left Side */}
              <div className="relative z-10 shrink-0">
                <div className="w-12 h-12 flex items-center justify-center text-2xl bg-slate-50 dark:bg-slate-800 rounded-lg transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1) shadow-sm border border-slate-100 dark:border-slate-700 group-hover:scale-110 group-hover:rotate-6 group-hover:border-white/0 dark:group-hover:border-slate-700/0 group-hover:bg-white/80 dark:group-hover:bg-slate-800/80 group-hover:shadow-md">
                    <div className="transform transition-transform duration-500 group-hover:scale-110">{benefit.icon}</div>
                </div>
              </div>
              
              {/* Content Section - Right Side */}
              <div className="relative z-10 pt-0.5">
                <h3 className="text-lg font-display font-bold text-slate-900 dark:text-white mb-1.5 group-hover:text-royal-700 dark:group-hover:text-royal-400 transition-colors duration-300 leading-tight">
                    {benefit.title}
                </h3>
                
                <p className="text-slate-500 dark:text-slate-400 leading-snug text-sm group-hover:text-slate-600 dark:group-hover:text-slate-300 transition-colors duration-300 font-medium">
                    {benefit.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;
