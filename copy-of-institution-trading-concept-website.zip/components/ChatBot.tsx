import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send, Minimize2, Sparkles } from 'lucide-react';
import { CHAT_TRIGGERS } from '../constants';
import { ChatMessage } from '../types';

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Initial greeting
  useEffect(() => {
    if (messages.length === 0) {
        setMessages([{
            id: 'welcome',
            text: "Hi! 👋 I'm your ITC Trading AI. Ask me anything about the course, pricing, or strategies!",
            sender: 'bot',
            timestamp: Date.now(),
            actionLink: '#contact-admin',
            actionLabel: 'Message Admin on Telegram'
        }]);
    }
  }, []);

  // Auto scroll
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = (text: string = inputValue) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
        id: Date.now().toString(),
        text: text,
        sender: 'user',
        timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    // Process Response
    setTimeout(() => {
        const lowerText = text.toLowerCase();
        const trigger = CHAT_TRIGGERS.find(t => t.keywords.some(k => lowerText.includes(k)));
        
        const responseText = trigger 
            ? trigger.response 
            : "That's a great question! For detailed information, please message our admin on Telegram @ITCadmin. I'm here to help! 😊";

        // Check if response mentions admin to add action button
        const hasAdminMention = responseText.includes('@ITCadmin');

        const botMsg: ChatMessage = {
            id: (Date.now() + 1).toString(),
            text: responseText,
            sender: 'bot',
            timestamp: Date.now(),
            actionLink: hasAdminMention ? 'https://t.me/ITCadmin' : undefined,
            actionLabel: hasAdminMention ? 'Message Admin on Telegram' : undefined
        };

        setMessages(prev => [...prev, botMsg]);
        setIsTyping(false);
    }, 1500);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans">
      
      {/* 3D AI Floating Orb */}
      {!isOpen && (
        <button 
            onClick={() => setIsOpen(true)}
            className="w-16 h-16 rounded-full flex items-center justify-center transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1) hover:scale-110 hover:-translate-y-2 animate-float relative group active:scale-95 will-change-transform"
            style={{
                background: 'radial-gradient(circle at 35% 35%, #e0f2fe 0%, #0ea5e9 40%, #0369a1 100%)',
                boxShadow: '0 15px 30px -5px rgba(14, 165, 233, 0.6), inset 0 0 20px rgba(255, 255, 255, 0.5)'
            }}
        >
            {/* Holographic Ring Animation */}
            <div className="absolute inset-0 rounded-full border-[1px] border-white/40 animate-ping opacity-20"></div>
            <div className="absolute inset-1 rounded-full border-t border-white/60 animate-spin" style={{ animationDuration: '3s' }}></div>
            
            {/* Icon */}
            <div className="relative z-10 text-white drop-shadow-md group-hover:rotate-12 transition-transform duration-300">
                <MessageCircle size={28} className="fill-white/10" />
            </div>
            
            {/* Notification Dot - 3D Style */}
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-br from-red-400 to-red-600 rounded-full border-2 border-white shadow-sm group-hover:scale-125 transition-transform"></span>
            
            {/* Tooltip */}
            <div className="absolute right-full mr-5 top-1/2 -translate-y-1/2 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md text-slate-800 dark:text-white px-4 py-2 rounded-xl text-xs font-bold shadow-xl opacity-0 group-hover:opacity-100 transition-all duration-300 whitespace-nowrap pointer-events-none transform translate-x-4 group-hover:translate-x-0 border border-white/50 dark:border-slate-700">
                Chat with AI
                <div className="absolute top-1/2 -right-1 -translate-y-1/2 w-2 h-2 bg-white dark:bg-slate-800 rotate-45"></div>
            </div>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="w-[350px] h-[520px] bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl rounded-[2rem] shadow-2xl flex flex-col overflow-hidden animate-fade-in-up border border-white/40 dark:border-slate-700 ring-1 ring-black/5 origin-bottom-right transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1)">
            
            {/* Header - Dark Glass with 3D Orb */}
            <div className="bg-slate-900 dark:bg-slate-950 p-4 flex justify-between items-center text-white relative overflow-hidden">
                {/* Abstract glow */}
                <div className="absolute top-[-50%] right-[-20%] w-40 h-40 bg-royal-500/40 rounded-full blur-3xl"></div>

                <div className="flex items-center gap-3 relative z-10">
                    {/* Mini 3D Orb Avatar */}
                    <div 
                        className="w-11 h-11 rounded-full flex items-center justify-center border border-white/10 shadow-[0_0_15px_rgba(14,165,233,0.4)]"
                        style={{
                            background: 'radial-gradient(circle at 35% 35%, #e0f2fe 0%, #0ea5e9 50%, #0284c7 100%)'
                        }}
                    >
                        <Sparkles size={18} className="text-white drop-shadow-sm animate-pulse" />
                    </div>
                    <div>
                        <h3 className="font-bold text-sm tracking-wide">ITC Assistant</h3>
                        <span className="text-[10px] text-emerald-400 flex items-center gap-1.5 font-medium bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 w-fit mt-0.5">
                            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.8)]"></span> 
                            AI Online
                        </span>
                    </div>
                </div>
                <div className="flex gap-2 relative z-10">
                    <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 p-2 rounded-full transition-colors hover:scale-110 active:scale-90"><Minimize2 size={18} /></button>
                </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50 dark:bg-slate-900/50">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                        <div className={`max-w-[85%] p-3.5 rounded-2xl text-sm shadow-sm leading-relaxed transition-transform duration-300 hover:scale-[1.02] ${
                            msg.sender === 'user' 
                                ? 'bg-gradient-to-br from-royal-600 to-royal-700 text-white rounded-br-none shadow-royal-500/20' 
                                : 'bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-bl-none hover:shadow-md'
                        }`}>
                            {msg.text}
                        </div>
                        {msg.actionLink && (
                            <a 
                                href={msg.actionLink} 
                                target="_blank" 
                                rel="noreferrer"
                                className="mt-2 text-[10px] bg-royal-600 text-white px-3 py-1.5 rounded-full font-bold uppercase tracking-wide hover:bg-royal-500 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) shadow-sm flex items-center gap-1 hover:shadow-lg hover:-translate-y-0.5 hover:scale-105"
                            >
                                {msg.actionLabel || 'Click Here'} <Send size={10} />
                            </a>
                        )}
                    </div>
                ))}
                {isTyping && (
                    <div className="flex justify-start">
                        <div className="bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 p-4 rounded-2xl rounded-bl-none shadow-sm flex gap-1.5 items-center">
                            <div className="w-2 h-2 bg-royal-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-royal-400 rounded-full animate-bounce delay-100"></div>
                            <div className="w-2 h-2 bg-royal-400 rounded-full animate-bounce delay-200"></div>
                        </div>
                    </div>
                )}
                <div ref={chatEndRef}></div>
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white dark:bg-slate-900 border-t border-slate-100/50 dark:border-slate-800/50">
                 {/* Smart Suggestions */}
                 {!isTyping && messages[messages.length-1]?.sender === 'bot' && (
                    <div className="flex gap-2 overflow-x-auto mb-4 pb-1 no-scrollbar mask-fade-right">
                        {['Price?', 'What is included?', 'Good for beginners?'].map(q => (
                            <button 
                                key={q} 
                                onClick={() => handleSendMessage(q)}
                                className="text-[11px] font-medium bg-slate-50 dark:bg-slate-800 hover:bg-royal-50 dark:hover:bg-royal-900/30 text-slate-600 dark:text-slate-300 hover:text-royal-600 dark:hover:text-royal-400 px-3 py-2 rounded-xl whitespace-nowrap border border-slate-200 dark:border-slate-700 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:scale-105 active:scale-95 hover:shadow-sm hover:-translate-y-0.5"
                            >
                                {q}
                            </button>
                        ))}
                    </div>
                 )}

                <div className="flex gap-2 relative bg-slate-100 dark:bg-slate-800 p-1.5 rounded-full border border-slate-200 dark:border-slate-700 focus-within:border-royal-300 focus-within:ring-2 focus-within:ring-royal-100 dark:focus-within:ring-royal-900 transition-all">
                    <input 
                        type="text" 
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="Ask about modules, pricing, or features..."
                        className="flex-1 bg-transparent px-4 py-2 text-sm focus:outline-none text-slate-800 dark:text-white placeholder-slate-400 dark:placeholder-slate-500"
                    />
                    <button 
                        onClick={() => handleSendMessage()}
                        disabled={!inputValue.trim()}
                        className="p-2.5 bg-royal-600 text-white rounded-full hover:bg-royal-700 transition-all duration-300 shadow-md disabled:opacity-50 disabled:shadow-none transform hover:scale-110 active:scale-90 disabled:transform-none"
                    >
                        <Send size={16} className={inputValue.trim() ? 'ml-0.5' : ''} />
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default ChatBot;