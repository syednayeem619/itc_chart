import React, { useState } from 'react';
import { Plus, Minus, Lock, PlayCircle } from 'lucide-react';
import { COURSE_MODULES } from '../constants';

const Curriculum: React.FC = () => {
  const [openModule, setOpenModule] = useState<string | null>('01');

  return (
    <section id="curriculum" className="py-32 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          <div className="sticky top-32 self-start">
            <span className="text-gold-500 font-bold tracking-widest text-xs uppercase mb-4 block">Inside the Course</span>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6 leading-tight">
              A Complete <br />
              <span className="text-gray-500">System for Success</span>
            </h2>
            <p className="text-gray-400 mb-8 leading-relaxed">
              Our curriculum is designed to take you from foundational concepts to institutional-grade execution. 
              Every module is crafted with precision, focusing on high-probability setups and rigorous risk management.
            </p>
            <div className="bg-white/5 border border-white/10 p-6 rounded-xl backdrop-blur-sm">
                <h4 className="text-white font-bold mb-2 flex items-center gap-2">
                   <Lock size={16} className="text-gold-500" /> 
                   Proprietary Trading Tools
                </h4>
                <p className="text-sm text-gray-400">Includes access to our custom volatility indicators and position sizing calculators used by hedge funds.</p>
            </div>
          </div>

          <div className="space-y-4">
            {COURSE_MODULES.map((module) => (
              <div 
                key={module.id} 
                className={`border transition-all duration-300 rounded-lg overflow-hidden ${openModule === module.id ? 'border-gold-500/50 bg-white/5' : 'border-white/10 bg-transparent hover:border-white/20'}`}
              >
                <button 
                  onClick={() => setOpenModule(openModule === module.id ? null : module.id)}
                  className="w-full flex items-center justify-between p-6 text-left group"
                >
                  <div className="flex items-center gap-6">
                    <span className={`text-2xl font-serif font-bold ${openModule === module.id ? 'text-gold-500' : 'text-gray-600 group-hover:text-gray-400'}`}>
                      {module.id}
                    </span>
                    <div>
                      <h3 className="text-lg font-bold text-white group-hover:text-gold-200 transition-colors">{module.title}</h3>
                      <p className="text-xs text-gray-500 uppercase tracking-wider mt-1">{module.duration}</p>
                    </div>
                  </div>
                  <span className={`text-gold-500 transition-transform duration-300 ${openModule === module.id ? 'rotate-180' : ''}`}>
                    {openModule === module.id ? <Minus size={20} /> : <Plus size={20} />}
                  </span>
                </button>

                <div className={`grid transition-all duration-500 ease-in-out ${openModule === module.id ? 'grid-rows-[1fr] opacity-100 pb-6' : 'grid-rows-[0fr] opacity-0'}`}>
                  <div className="overflow-hidden px-6 pl-20">
                    <ul className="space-y-3">
                      {module.lessons.map((lesson, idx) => (
                        <li key={idx} className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors cursor-pointer text-sm">
                          <PlayCircle size={14} className="text-gold-600" />
                          {lesson}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
};

export default Curriculum;