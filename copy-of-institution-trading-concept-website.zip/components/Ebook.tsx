import React from 'react';
import { Download, Book } from 'lucide-react';

const Ebook: React.FC = () => {
  return (
    <section id="ebook" className="py-20 bg-gradient-to-r from-turquoise-500 to-royal-600 relative overflow-hidden text-white">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          
          <div className="md:w-1/2">
            <div className="inline-block px-3 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-widest mb-6 backdrop-blur-sm">
              Included in Course
            </div>
            <h2 className="text-4xl font-display font-bold mb-6">
              Institutional Trading <br/> E-Book (70+ Pages)
            </h2>
            <p className="text-white/80 text-lg mb-8 leading-relaxed">
              A complete comprehensive guide to Demand & Supply zones, Multi-timeframe analysis, and execution strategies. Perfect for quick reference and deeper study.
            </p>
            <div className="grid grid-cols-2 gap-4 mb-8">
                {['Clear Annotations', 'Zone Marking Guide', 'Execution Rules', 'Risk Framework'].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm font-medium">
                        <Book size={16} className="text-gold-400" /> {item}
                    </div>
                ))}
            </div>
            
            <div className="flex items-center gap-4">
                <div>
                    <span className="text-slate-300 line-through text-sm">₹999</span>
                    <div className="text-3xl font-bold">₹499</div>
                </div>
                <button className="bg-white text-royal-600 hover:bg-slate-100 px-8 py-3 rounded-lg font-bold shadow-lg transition-colors flex items-center gap-2">
                    <Download size={18} /> Buy E-Book Only
                </button>
            </div>
          </div>

          <div className="md:w-1/2 flex justify-center">
             {/* CSS 3D Book Mockup */}
             <div className="relative w-64 h-80 group perspective-1000">
                <div className="relative w-full h-full transform-style-3d transition-transform duration-700 group-hover:rotate-y-[-20deg] animate-float">
                    {/* Front Cover */}
                    <div className="absolute inset-0 bg-slate-900 rounded-r-lg shadow-2xl flex flex-col items-center justify-center text-center p-6 border-l-4 border-slate-800 z-20">
                        <div className="text-gold-500 font-serif text-4xl font-bold mb-2">ITC</div>
                        <div className="text-white text-xs tracking-[0.3em] uppercase mb-8">Trading Strategy</div>
                        <div className="w-24 h-24 rounded-full border-2 border-gold-500/30 flex items-center justify-center mb-8">
                            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-gold-500 to-transparent opacity-20"></div>
                        </div>
                        <div className="mt-auto text-slate-400 text-xs">Institutional Guide</div>
                    </div>
                    {/* Pages */}
                    <div className="absolute top-1 right-2 w-full h-[98%] bg-white rounded-r-md transform translate-z-[-10px] shadow-lg"></div>
                    <div className="absolute top-1 right-4 w-full h-[98%] bg-white rounded-r-md transform translate-z-[-20px] shadow-lg"></div>
                </div>
             </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Ebook;