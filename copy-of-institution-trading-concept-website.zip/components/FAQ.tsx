import React, { useState } from 'react';
import { Plus, Minus, HelpCircle } from 'lucide-react';
import { FAQS } from '../constants';

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 bg-slate-50 dark:bg-slate-950 transition-colors duration-500 cubic-bezier(0.4, 0, 0.2, 1)">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-royal-100 dark:bg-royal-900/30 text-royal-600 dark:text-royal-400 text-xs font-bold uppercase tracking-widest mb-4 hover:shadow-md hover:scale-105 transition-all cursor-default hover:-translate-y-0.5">
             <HelpCircle size={14} /> FAQ
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 dark:text-white hover:scale-[1.01] transition-transform duration-500 origin-center">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-4">
          {FAQS.map((faq, index) => (
            <div 
              key={index} 
              className={`rounded-xl transition-all duration-400 cubic-bezier(0.34, 1.56, 0.64, 1) overflow-hidden border ${openIndex === index ? 'bg-white dark:bg-slate-900 border-royal-200 dark:border-royal-800 shadow-lg scale-[1.02] -translate-y-1' : 'bg-white dark:bg-slate-900 border-transparent hover:border-slate-200 dark:hover:border-slate-800 hover:shadow-md hover:scale-[1.01]'}`}
            >
              <button 
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left group"
              >
                <span className={`font-bold text-lg transition-colors duration-300 ${openIndex === index ? 'text-royal-700 dark:text-royal-400' : 'text-slate-800 dark:text-slate-200 group-hover:text-royal-600 dark:group-hover:text-royal-400'}`}>
                    {faq.question}
                </span>
                <span className={`transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1) p-1 rounded-full ${openIndex === index ? 'rotate-180 text-royal-500 bg-royal-50 dark:bg-royal-900/20' : 'text-slate-400 group-hover:text-royal-500 group-hover:bg-slate-50 dark:group-hover:bg-slate-800 group-hover:scale-110'}`}>
                   {openIndex === index ? <Minus size={20} /> : <Plus size={20} />}
                </span>
              </button>
              
              <div className={`transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] ${openIndex === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
                 <div className="px-6 pb-6 text-slate-600 dark:text-slate-400 leading-relaxed border-t border-slate-50 dark:border-slate-800 pt-4">
                    {faq.answer}
                 </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;