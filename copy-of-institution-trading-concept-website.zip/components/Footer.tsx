
import React, { useState } from 'react';
import { Twitter, Instagram, Send, Youtube } from 'lucide-react';
import LegalModal from './LegalModal';

const Footer: React.FC = () => {
  const [isLegalOpen, setIsLegalOpen] = useState(false);
  const [legalTab, setLegalTab] = useState<'refund' | 'privacy'>('refund');

  const openLegal = (tab: 'refund' | 'privacy') => {
    setLegalTab(tab);
    setIsLegalOpen(true);
  };

  return (
    <>
      <footer className="bg-slate-950 border-t border-slate-800 pt-16 pb-8 text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-1">
              <a href="#" className="text-2xl font-display font-bold tracking-tighter text-white block mb-6 group origin-left hover:scale-105 transition-transform duration-300">
                ITC<span className="text-turquoise-500 group-hover:text-gold-500 transition-colors duration-300">.</span>
              </a>
              <p className="text-sm leading-relaxed mb-6">
                Master institutional trading strategies specifically designed for the Indian Stock Market (NSE/BSE).
              </p>
              <div className="flex space-x-4">
                <a href="https://t.me/itc_charts" target="_blank" rel="noreferrer" className="hover:text-turquoise-500 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:scale-125 hover:-translate-y-1 hover:shadow-[0_0_20px_rgba(20,184,166,0.6)] hover:bg-turquoise-500/10 rounded-full p-2"><Send size={20} /></a>
                <a href="https://www.instagram.com/itc_charts?igsh=eDhzNnAzeTJuOXVv" target="_blank" rel="noreferrer" className="hover:text-pink-500 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:scale-125 hover:-translate-y-1 hover:shadow-[0_0_20px_rgba(236,72,153,0.6)] hover:bg-pink-500/10 rounded-full p-2"><Instagram size={20} /></a>
                <a href="https://youtube.com/@price_action_zone?si=AFujC31-YFLyscQr" target="_blank" rel="noreferrer" className="hover:text-red-500 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:scale-125 hover:-translate-y-1 hover:shadow-[0_0_20px_rgba(239,68,68,0.6)] hover:bg-red-500/10 rounded-full p-2"><Youtube size={20} /></a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-bold text-sm uppercase tracking-widest mb-6">Course</h4>
              <ul className="space-y-3 text-sm">
                <li><a href="#course" className="hover:text-white hover:pl-2 transition-all duration-300 block hover:translate-x-1">Curriculum</a></li>
                <li><a href="#benefits" className="hover:text-white hover:pl-2 transition-all duration-300 block hover:translate-x-1">Benefits</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold text-sm uppercase tracking-widest mb-6">Legal</h4>
              <ul className="space-y-3 text-sm">
                <li>
                    <button onClick={() => openLegal('refund')} className="hover:text-white hover:pl-2 transition-all duration-300 block hover:translate-x-1 text-left">Terms of Service</button>
                </li>
                <li>
                    <button onClick={() => openLegal('privacy')} className="hover:text-white hover:pl-2 transition-all duration-300 block hover:translate-x-1 text-left">Privacy Policy</button>
                </li>
                <li>
                    <button onClick={() => openLegal('refund')} className="hover:text-white hover:pl-2 transition-all duration-300 block hover:translate-x-1 text-left">Refund Policy</button>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold text-sm uppercase tracking-widest mb-6">Contact</h4>
              <ul className="space-y-3 text-sm">
                <li>
                  <a href="https://t.me/ITCadmin" target="_blank" rel="noreferrer" className="flex items-center gap-2 group cursor-pointer hover:text-white transition-colors hover:translate-x-1 duration-300">
                    <Send size={14} className="text-royal-500 group-hover:scale-125 group-hover:rotate-12 transition-transform duration-300" /> Telegram: @ITCadmin
                  </a>
                </li>
                <li className="text-xs bg-slate-900 inline-block px-2 py-1 rounded border border-slate-800 hover:border-royal-500/50 hover:text-royal-400 transition-all duration-300 cursor-default hover:scale-105 hover:-translate-y-0.5">Available 24/7</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
              <p className="text-xs">© 2026 ITC Trading. All rights reserved.</p>
              <p className="text-xs text-slate-600">Trading involves risk. Past performance doesn't guarantee future results.</p>
            </div>

            {/* SEBI Disclaimer */}
            <div className="border-t border-slate-900 pt-6 text-center">
                <p className="text-[10px] text-slate-600 leading-relaxed max-w-5xl mx-auto">
                    <strong className="text-slate-500">Disclaimer:</strong> We are not SEBI registered. The information, charts, courses, and materials on this website are intended purely for educational purposes. We do not offer investment advice, stock tips, or buy/sell recommendations. Trading involves risk, and users should consult their certified financial advisor before making any investment decisions. All decisions made by the user are entirely their own responsibility.
                </p>
            </div>
          </div>
        </div>
      </footer>
      <LegalModal isOpen={isLegalOpen} onClose={() => setIsLegalOpen(false)} initialTab={legalTab} />
    </>
  );
};

export default Footer;
