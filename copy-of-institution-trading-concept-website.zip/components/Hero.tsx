
import React, { useEffect, useState } from 'react';
import { ArrowRight, CheckCircle, Flame, Send } from 'lucide-react';

const Hero: React.FC = () => {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      requestAnimationFrame(() => {
         setScrollY(window.scrollY);
      });
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-white dark:bg-slate-950 pb-20 transition-colors duration-500 cubic-bezier(0.4, 0, 0.2, 1)">
      
      {/* Premium Background Effects with Parallax */}
      <div className="absolute inset-0 z-0 pointer-events-none">
         {/* Animated Blobs with Parallax */}
         <div 
           className="absolute top-[-10%] right-[-10%] w-[800px] h-[800px] transition-transform duration-75 ease-out will-change-transform"
           style={{ transform: `translateY(${scrollY * 0.2}px)` }}
         >
           <div className="w-full h-full bg-gradient-to-br from-royal-100/40 to-purple-100/40 dark:from-royal-900/20 dark:to-purple-900/20 rounded-full blur-[120px] animate-blob"></div>
         </div>

         <div 
           className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] transition-transform duration-75 ease-out will-change-transform"
           style={{ transform: `translateY(-${scrollY * 0.15}px)` }}
         >
            <div className="w-full h-full bg-gradient-to-tr from-turquoise-100/30 to-gold-100/30 dark:from-turquoise-900/10 dark:to-gold-900/10 rounded-full blur-[100px] animate-blob" style={{ animationDelay: '2s' }}></div>
         </div>
         
         <div 
            className="absolute top-[40%] left-[40%] w-[400px] h-[400px] transition-transform duration-75 ease-out will-change-transform"
            style={{ transform: `translateY(${scrollY * 0.1}px)` }}
         >
            <div className="w-full h-full bg-royal-50/50 dark:bg-royal-900/10 rounded-full blur-[80px] animate-blob" style={{ animationDelay: '4s' }}></div>
         </div>
        
        {/* Grid overlay with subtle parallax */}
        <div 
          className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] dark:opacity-[0.05] dark:invert transition-transform duration-75 ease-out will-change-transform"
          style={{ transform: `translateY(${scrollY * 0.05}px)` }}
        ></div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 pt-20">
        <div className="flex flex-col items-center text-center">
          
          {/* Content - Centered & Typography Focused */}
          <div className="w-full z-10">
            
            {/* ITC LOGO */}
            <div className="mb-8 animate-fade-in-up flex justify-center transition-transform duration-500 hover:scale-110 hover:rotate-3 cursor-pointer" style={{ transitionTimingFunction: 'cubic-bezier(0.34, 1.56, 0.64, 1)' }}>
                <img 
                    src="/itc-logo.png" 
                    alt="Institutional Trading Concept Logo" 
                    className="w-24 h-24 md:w-28 md:h-28 object-contain drop-shadow-[0_0_30px_rgba(255,255,255,0.4)] dark:drop-shadow-[0_0_30px_rgba(14,165,233,0.2)] hover:drop-shadow-[0_0_50px_rgba(14,165,233,0.5)] transition-all duration-500"
                    onError={(e) => {
                        // Fallback to a placeholder if image is missing
                        e.currentTarget.onerror = null;
                        e.currentTarget.src = "https://placehold.co/150x150/0f172a/ffffff?text=ITC";
                    }}
                />
            </div>

            {/* Ultra Premium Badge */}
            <div className="relative inline-flex items-center gap-3 px-8 py-2.5 rounded-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border border-royal-500/30 dark:border-royal-400/30 shadow-[0_0_30px_-5px_rgba(14,165,233,0.3)] mb-10 mx-auto animate-fade-in-up transition-all duration-500 hover:scale-[1.05] hover:shadow-[0_0_50px_-5px_rgba(14,165,233,0.5)] hover:border-royal-500/60 group overflow-hidden cursor-default z-20 ring-1 ring-white/50 dark:ring-white/10">
                
                {/* Shimmer Animation Layer */}
                <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-royal-400/20 to-transparent transform -skew-x-12 group-hover:animate-shine transition-all duration-1000"></div>
                
                {/* Pulsing Dot */}
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-royal-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-royal-500 shadow-[0_0_10px_rgba(14,165,233,0.8)]"></span>
                </span>

                {/* Text with Gradient */}
                <span className="text-[10px] sm:text-xs font-black tracking-[0.25em] uppercase text-transparent bg-clip-text bg-gradient-to-r from-slate-800 via-royal-600 to-slate-800 dark:from-white dark:via-royal-300 dark:to-white drop-shadow-sm">
                    Stop Doom, Start Edge
                </span>
            </div>

            <h1 className="text-5xl md:text-7xl lg:text-[6rem] font-display font-bold text-slate-900 dark:text-white mb-8 tracking-tighter leading-[1.1] animate-fade-in-up cursor-default" style={{ animationDelay: '0.1s' }}>
              Master <span className="text-transparent bg-clip-text bg-gradient-to-r from-royal-600 via-purple-600 to-royal-600 dark:from-royal-400 dark:via-purple-400 dark:to-royal-400 animate-shimmer bg-[length:200%_100%] hover:brightness-110 transition-all duration-300 filter hover:drop-shadow-[0_0_15px_rgba(14,165,233,0.3)]">
              Institutional <br/> Trading Concept
              </span>
            </h1>
            
            <p className="text-lg md:text-xl text-slate-500 dark:text-slate-400 mb-10 leading-relaxed max-w-2xl mx-auto font-light animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
              Learn Demand & Supply Zones, Multi-Timeframe Analysis & Risk Management. 
              Strategies used by <span className="font-medium text-slate-900 dark:text-white underline decoration-royal-500/30 underline-offset-4 hover:decoration-royal-500/80 transition-all duration-300 cursor-pointer hover:text-royal-600 dark:hover:text-royal-400">millions of professionals</span>, taught the right way by us.
            </p>

            {/* Key Points */}
            <div className="flex flex-wrap justify-center gap-x-8 gap-y-3 mb-12 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
                {[
                    "70%+ Win Rate Setups",
                    "Rated #1 for accuracy by top active traders in India",
                    "India-Focused NSE/BSE Strategies"
                ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3 group cursor-default transition-transform duration-300 hover:scale-[1.03] hover:-translate-y-0.5 will-change-transform">
                        <div className="w-6 h-6 rounded-full bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-800 flex items-center justify-center group-hover:scale-110 group-hover:bg-green-100 dark:group-hover:bg-green-900/50 transition-all duration-300 shadow-sm group-hover:shadow-md cubic-bezier(0.4, 0, 0.2, 1)">
                            <CheckCircle size={14} className="text-green-600 dark:text-green-400" />
                        </div>
                        <span className="font-medium text-slate-700 dark:text-slate-300 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">{item}</span>
                    </div>
                ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-col items-center gap-6 animate-fade-in-up w-full max-w-lg mx-auto" style={{ animationDelay: '0.4s' }}>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-5 w-full">
                  <a 
                    href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20am%20interested%20in%20the%20ITC%20Master%20Course"
                    target="_blank"
                    rel="noreferrer"
                    className="relative px-10 py-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-sm uppercase tracking-widest rounded-xl shadow-xl transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1) hover:shadow-[0_0_50px_rgba(34,197,94,0.8)] hover:scale-[1.05] hover:-translate-y-1.5 w-full text-center overflow-hidden group active:scale-95 will-change-transform border border-transparent hover:border-green-400/50"
                  >
                    {/* Hover Layer (Radioactive Green) */}
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-600 via-green-500 to-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    
                    {/* Shimmer Effect */}
                    <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/30 to-transparent transform -skew-x-12 group-hover:animate-shine transition-all duration-1000"></div>
                    
                    <span className="relative flex items-center justify-center gap-2 group-hover:text-white transition-colors z-10">
                       Enroll in Master Course <span className="text-white/70 dark:text-slate-900/70 group-hover:text-white/90 transition-colors">- ₹4,999</span>
                    </span>
                  </a>
                  
                  <a 
                    href="https://t.me/itc_charts" 
                    target="_blank"
                    rel="noreferrer"
                    className="relative group w-full px-8 py-4 rounded-xl overflow-hidden transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1) hover:-translate-y-1.5 hover:scale-[1.02] hover:shadow-[0_20px_40px_-10px_rgba(34,158,217,0.5)] active:scale-95 border border-slate-200 dark:border-slate-700 hover:border-[#229ED9] dark:hover:border-[#229ED9] bg-white dark:bg-slate-800"
                  >
                    {/* Hover Gradient Background - Fades in */}
                    <div className="absolute inset-0 bg-gradient-to-r from-[#229ED9] to-[#0088cc] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    
                     {/* Shimmer */}
                     <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 group-hover:animate-shine transition-all duration-1000"></div>

                    {/* Content */}
                    <div className="relative z-10 flex flex-col items-center justify-center gap-0.5">
                       <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 group-hover:text-white transition-colors duration-300">
                           <Send size={18} className="group-hover:-translate-y-1 group-hover:translate-x-1 transition-transform duration-500 ease-out" />
                           <span className="font-bold text-sm tracking-wide">Join Telegram (itc_charts)</span>
                       </div>
                       <span className="text-[10px] font-medium text-slate-400 group-hover:text-blue-100 transition-colors duration-300">for daily charts updates</span>
                    </div>
                  </a>
                </div>

                {/* FOMO COMBO BUTTON - ULTRA PREMIUM SUPER GREEN ENHANCEMENT */}
                <a 
                   href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20am%20interested%20in%20the%20ITC%20Combo%20Pack"
                   target="_blank"
                   rel="noreferrer"
                   className="relative group w-full sm:w-auto px-6 py-3 rounded-xl shadow-[0_0_20px_rgba(239,68,68,0.3)] transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1) hover:shadow-[0_0_50px_rgba(34,197,94,0.6)] hover:scale-[1.04] hover:-translate-y-1 flex items-center justify-center gap-4 overflow-hidden border border-red-400/50 hover:border-emerald-400/60 text-left active:scale-[0.98] will-change-transform"
                >
                    {/* 1. Base Layer (Red Gradient) */}
                    <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-red-500 transition-opacity duration-500 group-hover:opacity-0"></div>
                    
                    {/* 2. Premium Super Green Layer (Fades in on Hover/Touch) */}
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    
                    {/* 3. Shine Animation */}
                    <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shine group-hover:animate-none group-hover:translate-x-[200%] transition-transform duration-1000"></div>
                    
                    {/* Content */}
                    <Flame size={28} className="text-yellow-300 fill-yellow-300 animate-pulse shrink-0 hidden sm:block filter drop-shadow-lg group-hover:scale-110 group-hover:fill-white group-hover:text-white transition-all duration-500 relative z-10" />
                    
                    <div className="flex flex-col items-start leading-tight relative z-10">
                        <div className="text-[11px] font-bold text-yellow-100 uppercase tracking-wide mb-1 group-hover:text-white transition-colors duration-300">
                            ITC Master Course + E-book Combo Pack
                        </div>
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                             <div className="flex items-center gap-2">
                                <span className="text-[10px] font-medium text-red-200 group-hover:text-emerald-100 line-through decoration-white/50 transition-colors duration-300">4999 + 499 = ₹5,498</span>
                                <span className="text-[9px] font-extrabold bg-yellow-400 text-red-900 px-1.5 py-0.5 rounded shadow-sm whitespace-nowrap group-hover:bg-white group-hover:text-emerald-700 group-hover:shadow-lg transition-all duration-300">SAVE ₹399</span>
                             </div>
                             <div className="text-sm font-medium text-white">
                                4999 + 99 = <span className="text-lg font-black text-white tracking-tight group-hover:scale-110 inline-block transition-transform duration-300 drop-shadow-md">₹5,098</span>
                             </div>
                        </div>
                    </div>
                    
                    <ArrowRight size={20} className="text-white group-hover:translate-x-1.5 transition-transform duration-300 shrink-0 ml-auto sm:ml-0 relative z-10" />
                </a>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;
