import React, { useEffect, useState } from 'react';
import { X, Shield, Lock, FileText, AlertTriangle } from 'lucide-react';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'refund' | 'privacy';
}

const LegalModal: React.FC<LegalModalProps> = ({ isOpen, onClose, initialTab = 'refund' }) => {
  const [activeTab, setActiveTab] = useState<'refund' | 'privacy'>('refund');

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-md transition-opacity duration-300" 
        onClick={onClose}
      ></div>
      
      {/* Modal Container */}
      <div className="relative bg-white dark:bg-slate-950 w-full max-w-4xl h-[80vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-fade-in-up border border-slate-200 dark:border-slate-800 transition-all duration-500">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md z-10">
            <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300">
                    <FileText size={20} />
                </div>
                <h2 className="text-2xl font-display font-bold text-slate-900 dark:text-white">Legal Information</h2>
            </div>
            <button 
                onClick={onClose} 
                className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-all duration-300 hover:rotate-90 active:scale-95"
            >
                <X size={24} className="text-slate-500" />
            </button>
        </div>

        <div className="flex flex-col md:flex-row h-full overflow-hidden">
            {/* Sidebar Navigation */}
            <div className="w-full md:w-64 bg-slate-50 dark:bg-slate-900/50 border-b md:border-b-0 md:border-r border-slate-100 dark:border-slate-800 p-4 flex md:flex-col gap-2 shrink-0 overflow-x-auto md:overflow-x-visible">
                <button 
                    onClick={() => setActiveTab('refund')}
                    className={`flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-bold transition-all duration-300 w-full text-left ${
                        activeTab === 'refund' 
                            ? 'bg-royal-500 text-white shadow-lg shadow-royal-500/30 translate-x-1' 
                            : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 hover:translate-x-1'
                    }`}
                >
                    <Shield size={18} /> Refund Policy
                </button>
                <button 
                    onClick={() => setActiveTab('privacy')}
                    className={`flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-bold transition-all duration-300 w-full text-left ${
                        activeTab === 'privacy' 
                            ? 'bg-royal-500 text-white shadow-lg shadow-royal-500/30 translate-x-1' 
                            : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 hover:translate-x-1'
                    }`}
                >
                    <Lock size={18} /> Privacy Policy
                </button>
            </div>

            {/* Scrollable Content Area */}
            <div className="flex-1 overflow-y-auto p-6 md:p-10 bg-white dark:bg-slate-950 scroll-smooth">
                {activeTab === 'refund' && (
                    <div className="animate-fade-in-up space-y-8">
                        <div>
                            <h3 className="text-3xl font-display font-bold mb-2 text-slate-900 dark:text-white">Refund Policy</h3>
                            <p className="text-slate-500 dark:text-slate-400 text-sm">Last updated: October 2023</p>
                        </div>
                        
                        {/* Important Notice Box */}
                        <div className="bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 rounded-2xl p-6 flex gap-4">
                            <div className="shrink-0 w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center text-red-600 dark:text-red-400">
                                <AlertTriangle size={20} />
                            </div>
                            <div>
                                <h4 className="text-red-700 dark:text-red-400 font-bold text-lg mb-1">No Refund After Enrollment</h4>
                                <p className="text-sm text-red-600/80 dark:text-red-300/80 leading-relaxed">
                                    <strong>Important Notice:</strong> All course enrollments are final. Once you have enrolled in any course or program, no refunds will be issued under any circumstances.
                                </p>
                            </div>
                        </div>

                        <div className="space-y-6 text-slate-600 dark:text-slate-300">
                            <section>
                                <h4 className="text-slate-900 dark:text-white font-bold text-lg mb-3 flex items-center gap-2">
                                    <span className="w-1.5 h-1.5 bg-royal-500 rounded-full"></span> Key Points
                                </h4>
                                <ul className="space-y-3 pl-2 border-l-2 border-slate-100 dark:border-slate-800 ml-1">
                                    <li className="pl-4 text-sm leading-relaxed">
                                        <strong className="text-slate-900 dark:text-white block mb-1">No Refunds</strong>
                                        After successful enrollment and payment, refunds will not be provided for any reason, including but not limited to: change of mind, inability to complete the course, dissatisfaction with content, technical difficulties on user's end, or personal circumstances.
                                    </li>
                                    <li className="pl-4 text-sm leading-relaxed">
                                        <strong className="text-slate-900 dark:text-white block mb-1">Non-Transferable</strong>
                                        Course enrollments are non-transferable to other individuals or programs.
                                    </li>
                                    <li className="pl-4 text-sm leading-relaxed">
                                        <strong className="text-slate-900 dark:text-white block mb-1">Pre-Enrollment Review</strong>
                                        We strongly encourage all prospective students to thoroughly review course details, curriculum, duration, and requirements before enrolling.
                                    </li>
                                    <li className="pl-4 text-sm leading-relaxed">
                                        <strong className="text-slate-900 dark:text-white block mb-1">Payment Confirmation</strong>
                                        By completing payment and enrollment, you acknowledge and accept this no-refund policy.
                                    </li>
                                </ul>
                            </section>

                            <section className="mt-8 pt-8 border-t border-slate-100 dark:border-slate-800">
                                <h4 className="text-slate-900 dark:text-white font-bold text-lg mb-4">Exceptions</h4>
                                <p className="text-sm mb-4">Refunds may only be considered in the following exceptional circumstances:</p>
                                <ul className="list-disc pl-5 space-y-2 text-sm">
                                    <li>Course cancellation by the service provider.</li>
                                    <li>Technical issues on the provider's platform that prevent course access for an extended period (to be determined at provider's discretion).</li>
                                </ul>
                            </section>

                            <div className="bg-slate-50 dark:bg-slate-900 rounded-2xl p-6 border border-slate-100 dark:border-slate-800">
                                <h4 className="text-slate-900 dark:text-white font-bold text-lg mb-3">SEBI Registration Disclaimer</h4>
                                <p className="text-sm mb-4 font-medium">Important Disclosure: We are <strong>NOT registered</strong> with the Securities and Exchange Board of India (SEBI).</p>
                                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                    {['Educational purposes only', 'No investment advice provided', 'Consult SEBI advisors for investing', 'No financial return guarantees'].map((item, i) => (
                                        <li key={i} className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 p-2 rounded-lg border border-slate-200 dark:border-slate-700">
                                            <div className="w-1 h-1 bg-slate-400 rounded-full"></div> {item}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === 'privacy' && (
                    <div className="animate-fade-in-up space-y-8 text-slate-600 dark:text-slate-300">
                        <div>
                            <h3 className="text-3xl font-display font-bold mb-2 text-slate-900 dark:text-white">Privacy Policy</h3>
                            <p className="text-slate-500 dark:text-slate-400 text-sm">Your privacy is important to us.</p>
                        </div>

                        <div className="space-y-8">
                            <section>
                                <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-3 border-b border-slate-100 dark:border-slate-800 pb-2">Information We Collect</h4>
                                <div className="grid md:grid-cols-2 gap-4">
                                    <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-xl">
                                        <strong className="block text-slate-900 dark:text-white mb-2 text-sm">Personal Information</strong>
                                        <ul className="text-sm space-y-1 list-disc pl-4">
                                            <li>Name, email address, phone number</li>
                                            <li>Payment and billing information</li>
                                            <li>Educational background (if provided)</li>
                                        </ul>
                                    </div>
                                    <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-xl">
                                        <strong className="block text-slate-900 dark:text-white mb-2 text-sm">Technical Information</strong>
                                        <ul className="text-sm space-y-1 list-disc pl-4">
                                            <li>IP address, browser type, device info</li>
                                            <li>Course access logs and progress</li>
                                            <li>Cookies and tracking technologies</li>
                                        </ul>
                                    </div>
                                </div>
                            </section>

                            <section>
                                <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-3">How We Use Your Information</h4>
                                <ul className="list-disc pl-5 text-sm space-y-2">
                                    <li>Processing course enrollments and payments</li>
                                    <li>Delivering course content and materials</li>
                                    <li>Communicating about courses, updates, and support</li>
                                    <li>Improving our services and user experience</li>
                                    <li>Complying with legal obligations and preventing fraud</li>
                                </ul>
                            </section>

                            <section>
                                <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-3">Information Sharing</h4>
                                <p className="text-sm mb-2">We do <strong>NOT</strong> sell your personal information. We may share information with:</p>
                                <ul className="list-disc pl-5 text-sm space-y-1">
                                    <li>Payment processors (for transaction processing)</li>
                                    <li>Service providers (hosting, email delivery, analytics)</li>
                                    <li>Legal authorities (when required by law)</li>
                                </ul>
                            </section>

                            <section>
                                <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-3">Data Security & Retention</h4>
                                <p className="text-sm mb-3">We implement appropriate security measures (SSL/TLS, secure gateways). We retain your information for as long as necessary to provide services and comply with legal obligations.</p>
                            </section>
                            
                            <section>
                                <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-3">Your Rights</h4>
                                <p className="text-sm mb-3">You have the right to access, correct, or request deletion of your personal data. You may also opt-out of marketing communications.</p>
                            </section>

                            <div className="bg-royal-50 dark:bg-royal-900/20 p-6 rounded-xl border border-royal-100 dark:border-royal-800/50">
                                <h4 className="text-royal-700 dark:text-royal-400 font-bold mb-2">Contact Us</h4>
                                <p className="text-sm mb-1">For privacy related queries, please contact us via Telegram.</p>
                                <a href="https://t.me/ITCadmin" target="_blank" rel="noreferrer" className="text-sm font-bold text-royal-600 dark:text-royal-400 hover:underline">@ITCadmin</a>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default LegalModal;