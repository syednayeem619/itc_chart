
import React, { useState, useEffect, useRef } from 'react';
import { Plus, Minus, Check, Star, Zap, Book, Download, ChevronRight, Crown, PlayCircle, Flame, X, Timer, Gift } from 'lucide-react';
import { COURSE_MODULES } from '../constants';

const MasterCourse: React.FC = () => {
  const [openModule, setOpenModule] = useState<string | null>('01');
  const [showPopup, setShowPopup] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          const hasSeenPopup = sessionStorage.getItem('comboPopupShown');
          if (!hasSeenPopup) {
            // Small delay for natural feel
            setTimeout(() => {
                setShowPopup(true);
                sessionStorage.setItem('comboPopupShown', 'true');
            }, 1500);
          }
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const handleClosePopup = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setShowPopup(false);
  };

  return (
    <section id="course" ref={sectionRef} className="py-16 bg-slate-50 dark:bg-slate-950 relative overflow-hidden transition-colors duration-500">
      
      {/* POPUP MODAL */}
      {showPopup && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
            {/* Backdrop */}
            <div 
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in-up" 
                onClick={() => handleClosePopup()}
            ></div>
            
            {/* Modal Content */}
            <div className="relative bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl shadow-2xl border border-gold-500/30 overflow-hidden animate-fade-in-up transform scale-100 transition-all duration-500 hover:shadow-gold-500/20 hover:scale-[1.01]">
                {/* Header Gradient */}
                <div className="bg-gradient-to-r from-red-600 to-red-500 p-4 text-white text-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 pointer-events-none"></div>
                    <h3 className="text-xl font-bold uppercase tracking-widest relative z-10 flex items-center justify-center gap-2">
                        <Flame size={20} className="fill-yellow-400 text-yellow-400 animate-pulse" /> 
                        Limited Offer
                    </h3>
                    <button 
                        onClick={handleClosePopup}
                        className="absolute top-1/2 -translate-y-1/2 right-3 text-white/80 hover:text-white hover:bg-white/10 p-2 rounded-full transition-all z-20 cursor-pointer hover:rotate-90 hover:scale-110"
                        aria-label="Close popup"
                    >
                        <X size={20} />
                    </button>
                </div>
                
                <div className="p-8 text-center">
                    <p className="text-slate-500 dark:text-slate-400 font-medium mb-4 text-sm uppercase tracking-wide">Wait! Don't miss this deal</p>
                    <h2 className="text-3xl font-display font-bold text-slate-900 dark:text-white mb-2">
                        Save <span className="text-red-500">₹399</span> Instantly
                    </h2>
                    <p className="text-slate-600 dark:text-slate-300 mb-8 text-sm leading-relaxed">
                        Get the <strong>Master Course + E-Book Guide</strong> together in the Combo Pack.
                    </p>
                    
                    <div className="flex items-center justify-center gap-4 mb-8">
                        <div className="text-center">
                            <div className="text-xs text-slate-400 line-through">₹5,498</div>
                            <div className="text-xl font-bold text-slate-900 dark:text-white">₹5,098</div>
                        </div>
                        <div className="h-8 w-px bg-slate-200 dark:bg-slate-700"></div>
                        <div className="text-left">
                            <div className="text-[10px] font-bold uppercase text-gold-500 tracking-wider">Best Value</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">Complete Suite</div>
                        </div>
                    </div>

                    <a 
                        href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20am%20interested%20in%20the%20ITC%20Combo%20Pack"
                        target="_blank"
                        rel="noreferrer"
                        onClick={() => handleClosePopup()}
                        className="group relative block w-full py-4 bg-gradient-to-r from-gold-400 to-gold-500 text-slate-900 font-extrabold rounded-xl shadow-lg transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1) hover:shadow-[0_0_50px_rgba(34,197,94,0.8)] hover:scale-[1.03] hover:-translate-y-1 uppercase tracking-widest text-xs active:scale-95 overflow-hidden"
                    >
                        {/* Radioactive Green Hover Layer */}
                        <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        
                        {/* Shimmer */}
                        <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/40 to-transparent transform -skew-x-12 group-hover:animate-shine transition-all duration-1000"></div>

                        <span className="relative z-10 group-hover:text-white transition-colors duration-300">Claim Combo Deal Now</span>
                    </a>
                    <button 
                        onClick={(e) => handleClosePopup(e)}
                        className="mt-4 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-medium w-full py-2 cursor-pointer transition-colors hover:underline"
                    >
                        No thanks, I'll pay full price
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Luxurious Background Texture */}
      <div className="absolute inset-0 bg-[#fafafa] dark:bg-slate-950 transition-colors duration-300">
         <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05] dark:invert" style={{ backgroundImage: 'url("https://www.transparenttextures.com/patterns/diamond-upholstery.png")' }}></div>
         {/* Gold ambient glows */}
         <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-[radial-gradient(circle_at_center,rgba(250,204,21,0.05),transparent_70%)] dark:bg-[radial-gradient(circle_at_center,rgba(250,204,21,0.03),transparent_70%)] pointer-events-none"></div>
         <div className="absolute bottom-0 left-0 w-[800px] h-[800px] bg-[radial-gradient(circle_at_center,rgba(14,165,233,0.05),transparent_70%)] dark:bg-[radial-gradient(circle_at_center,rgba(14,165,233,0.03),transparent_70%)] pointer-events-none"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header - Compact & Professional */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-slate-800 dark:text-slate-200 text-[10px] font-bold uppercase tracking-[0.2em] mb-4 animate-fade-in-up transition-transform duration-300 hover:scale-105 hover:shadow-md cursor-default hover:-translate-y-0.5">
             <span className="w-1.5 h-1.5 bg-slate-900 dark:bg-white rounded-full animate-pulse"></span> Elite Training Program
          </div>
          <h2 className="text-3xl md:text-4xl font-sans font-extrabold text-slate-900 dark:text-white mb-3 tracking-tight">
            Stop Doom, Start Edge
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-medium max-w-2xl mx-auto leading-relaxed font-sans">
            Start your professional trading journey. Learn High Probability Trading Concepts now.
          </p>
        </div>

        {/* Pricing Grid - Compact Spacing */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-16">
          
          {/* Left Column: Master Course - THE BLACK CARD AESTHETIC */}
          <div className="group relative rounded-[2rem] overflow-hidden transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1) hover:-translate-y-3 hover:scale-[1.02] hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.6)] will-change-transform h-full flex flex-col">
            
            {/* Background - Deep Midnight with Noise */}
            <div className="absolute inset-0 bg-[#0B1120]">
                <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]"></div>
                {/* Subtle Gradient Sheen */}
                <div className="absolute -top-[50%] -left-[50%] w-[200%] h-[200%] bg-gradient-to-br from-white/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none rotate-12"></div>
            </div>
            
            <div className="relative z-10 p-8 md:p-10 flex flex-col h-full text-white">
                {/* Card Header */}
                <div className="flex justify-between items-start mb-8">
                    <div className="transform transition-transform duration-300 group-hover:translate-x-2">
                        <div className="flex items-center gap-2 text-gold-400 text-[10px] font-bold uppercase tracking-[0.25em] mb-2">
                            <Crown size={12} className="fill-gold-400" /> Most Recommended
                        </div>
                        <h3 className="text-3xl font-serif text-white mb-1 tracking-wide">Master Course</h3>
                        <p className="text-[10px] text-slate-400 font-medium uppercase tracking-widest border-l-2 border-gold-500/50 pl-3">Video Mentorship Program</p>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gold-400 to-gold-600 p-[1px] shadow-[0_0_20px_rgba(250,204,21,0.3)] group-hover:shadow-[0_0_40px_rgba(250,204,21,0.6)] group-hover:scale-110 group-hover:rotate-12 transition-all duration-500">
                        <div className="w-full h-full rounded-full bg-[#0B1120] flex items-center justify-center">
                             <Star className="fill-gold-500 text-gold-500 group-hover:animate-pulse" size={18} />
                        </div>
                    </div>
                </div>
                
                {/* Pricing */}
                <div className="mb-8 pb-8 border-b border-white/10">
                  <div className="flex items-baseline gap-3">
                    <span className="text-slate-500 line-through text-lg font-serif decoration-slate-500/50 animate-fade-in-up" style={{ animationDuration: '3s' }}>₹10,000</span>
                    <span className="text-5xl font-serif text-white tracking-tight group-hover:text-gold-100 transition-colors">₹4,999</span>
                  </div>
                  <p className="text-gold-500/80 text-[10px] mt-2 font-medium tracking-wide">+ 2 Months Premium Access Included</p>
                </div>

                {/* Features */}
                <div className="space-y-4 mb-8 flex-1">
                    {[
                        "13 Recorded Videos (Basic to Advanced)",
                        "1 Year Full Access",
                        "Institutional Screeners",
                        "Custom Indicators",
                        "Premium Discussion Group*"
                    ].map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-3 text-sm font-light text-slate-300 group-hover:text-white transition-colors duration-300 translate-x-0 group-hover:translate-x-2" style={{ transitionDelay: `${idx * 50}ms` }}>
                            <div className="w-5 h-5 rounded-full border border-gold-500/30 flex items-center justify-center shrink-0 group-hover:border-gold-500 group-hover:bg-gold-500/10 transition-all shadow-sm group-hover:shadow-[0_0_10px_rgba(234,179,8,0.3)]">
                                <Check size={10} className="text-gold-400" />
                            </div>
                            {feature}
                        </div>
                    ))}
                     <p className="text-[10px] text-slate-500 ml-8 italic leading-relaxed">*2 Months Premium Discussion Group for Like-Minded Traders <br/>(Unlocked only after completing course)</p>
                </div>
                
                {/* CTA - Super Green Radioactive Effect */}
                <div className="mt-auto">
                    <a 
                        href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20am%20interested%20in%20the%20ITC%20Master%20Course"
                        target="_blank"
                        rel="noreferrer"
                        className="group/btn relative block w-full overflow-hidden rounded-xl bg-gradient-to-r from-gold-400 to-gold-500 text-slate-900 font-extrabold uppercase tracking-[0.2em] text-xs shadow-lg transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1) hover:shadow-[0_0_50px_rgba(34,197,94,0.8)] hover:-translate-y-1 hover:scale-[1.02] active:scale-95"
                    >
                        {/* Radioactive Green Hover Layer */}
                        <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300 ease-out"></div>
                        
                        {/* Shimmer */}
                        <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/40 to-transparent transform -skew-x-12 group-hover/btn:animate-shine transition-all duration-1000"></div>

                        <div className="relative py-5 flex items-center justify-center gap-3 z-10 group-hover/btn:text-white transition-colors duration-300">
                            Enroll in Master Course <ChevronRight size={14} className="group-hover/btn:translate-x-1 transition-transform duration-300" />
                        </div>
                    </a>
                    
                    <div className="flex justify-center gap-4 mt-4 opacity-40 grayscale transition-all duration-500 group-hover:opacity-100 group-hover:grayscale-0">
                        {/* Trust Badges */}
                        <span className="text-[10px] text-slate-400 flex items-center gap-1"><div className="w-1 h-1 bg-green-500 rounded-full"></div>Instant Access</span>
                        <span className="text-[10px] text-slate-400 flex items-center gap-1"><div className="w-1 h-1 bg-green-500 rounded-full"></div>Secure Payment</span>
                    </div>
                </div>
            </div>
          </div>

          {/* Right Column: E-Book & Combo */}
          <div className="flex flex-col gap-4">
            
            {/* Option 2: E-Book Only - COMPACT & CLEAR REDESIGN */}
            <div className="group relative bg-white dark:bg-slate-900 rounded-[2rem] overflow-hidden border border-slate-200 dark:border-slate-800 transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1) hover:-translate-y-2 hover:scale-[1.02] hover:border-royal-500/30 dark:hover:border-royal-500/30 hover:shadow-[0_15px_30px_-10px_rgba(0,0,0,0.1)] will-change-transform">
                
                {/* Subtle Top Gradient */}
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-turquoise-400 to-royal-500 transform origin-left scale-x-50 group-hover:scale-x-100 transition-transform duration-500"></div>

                <div className="p-6 flex flex-row items-center justify-between gap-6 relative z-10">
                    
                    {/* Left: Content */}
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                             <div className="w-1.5 h-1.5 rounded-full bg-royal-500 animate-pulse"></div>
                             <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Self-Paced</span>
                        </div>
                        
                        <h3 className="text-lg md:text-xl font-serif font-bold text-slate-900 dark:text-white leading-tight mb-2 truncate">
                            Institutional E-Book
                        </h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mb-3 font-medium">70+ Pages • PDF Guide • Lifetime Access</p>
                        
                        {/* Topics Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-1 gap-y-1 mb-3">
                            {['Clear Annotations', 'Zone Marking Guide', 'Execution Rules', 'Risk Framework', 'Clear images to understand ITC'].map((topic, i) => (
                                <div key={i} className="flex items-center gap-1.5 text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                                    <Check size={10} className="text-royal-500 shrink-0" /> {topic}
                                </div>
                            ))}
                        </div>
                        
                        <div className="flex items-center gap-3 mb-1">
                            <span className="text-slate-400 line-through text-xs font-serif decoration-red-400/50">₹999</span>
                            <span className="text-2xl font-serif text-slate-900 dark:text-white font-bold group-hover:text-royal-600 dark:group-hover:text-royal-400 transition-colors">₹499</span>
                        </div>

                        <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase tracking-wide mb-3 flex items-center gap-1">
                            <Zap size={10} className="fill-current" /> Instant Digital Delivery
                        </div>

                        <a 
                            href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20am%20interested%20in%20the%20ITC%20E-Book"
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[10px] font-bold uppercase tracking-widest rounded-lg shadow-md transition-all duration-300 hover:scale-105 active:scale-95 hover:shadow-[0_0_30px_rgba(34,197,94,0.6)] group/btn relative overflow-hidden"
                        >
                             {/* Radioactive Green Hover Layer */}
                             <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300 ease-out rounded-lg z-0"></div>
                             
                             {/* Shimmer */}
                             <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/40 to-transparent transform -skew-x-12 group-hover/btn:animate-shine transition-all duration-1000"></div>

                             <span className="relative z-10 flex items-center gap-2 group-hover/btn:text-white transition-colors">
                                Buy E-Book <Download size={12} className="group-hover/btn:translate-y-0.5 transition-transform" />
                             </span>
                        </a>
                    </div>

                    {/* Right: Simple Classic Book Icon */}
                    <div className="shrink-0 pr-2">
                        <div className="w-24 h-24 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center border border-slate-100 dark:border-slate-700 shadow-sm group-hover:scale-110 transition-transform duration-500 group-hover:shadow-md group-hover:border-royal-200 dark:group-hover:border-royal-800">
                             <Book size={40} className="text-slate-400 group-hover:text-royal-500 transition-colors duration-300" strokeWidth={1.5} />
                        </div>
                    </div>

                </div>
            </div>

            {/* NEW Option 3: Combo Pack Small Card */}
            <div className="group relative bg-gradient-to-br from-slate-950 to-slate-900 rounded-[2rem] border border-gold-500/30 overflow-hidden transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1) hover:border-emerald-500 hover:shadow-[0_0_50px_-10px_rgba(16,185,129,0.3)] hover:-translate-y-2 hover:scale-[1.02] will-change-transform">
                
                 {/* Animated Border Gradient */}
                <div className="absolute inset-0 bg-gradient-to-r from-gold-500/20 via-transparent to-emerald-500/20 opacity-50 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>

                <div className="p-6 flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
                    
                    <div className="flex-1 text-center md:text-left">
                        <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
                            <div className="px-2 py-0.5 rounded bg-red-500/20 border border-red-500/30 text-red-400 text-[10px] font-bold uppercase tracking-widest flex items-center gap-1 animate-pulse">
                                <Flame size={10} className="fill-red-400" /> Limited Offer
                            </div>
                        </div>
                        <h3 className="text-xl font-serif text-white font-bold mb-2">Master Course + E-Book</h3>
                        
                        <div className="flex flex-col md:flex-row items-center gap-2 md:gap-4 mt-2">
                            <div className="text-slate-500 text-xs line-through decoration-red-500/50 decoration-2">4999 + 499</div>
                            <div className="flex items-center gap-1 text-sm text-white font-medium">
                                4999 + 99 = <span className="text-emerald-400 font-bold text-lg">₹5,098</span>
                            </div>
                        </div>
                    </div>

                    <div className="flex flex-col items-center gap-2 shrink-0 w-full md:w-auto">
                        {/* Savings Badge - Moved above button for visibility */}
                        <div className="animate-bounce bg-red-600 text-white text-[10px] font-bold px-3 py-0.5 rounded-full shadow-lg shadow-red-600/40 z-20">
                            🔥 Save ₹399 Instantly
                        </div>

                        <a 
                            href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20am%20interested%20in%20the%20ITC%20Combo%20Pack"
                            target="_blank"
                            rel="noreferrer"
                            className="group/btn relative w-full md:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-gold-400 to-gold-500 text-slate-900 font-extrabold uppercase tracking-widest text-xs shadow-lg transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1) hover:shadow-[0_0_50px_rgba(34,197,94,0.8)] hover:-translate-y-1 hover:scale-[1.03] active:scale-95 overflow-hidden flex items-center justify-center gap-2"
                        >
                            {/* Radioactive Green Hover Layer */}
                            <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300 ease-out"></div>
                            
                            {/* Shimmer */}
                            <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/40 to-transparent transform -skew-x-12 group-hover/btn:animate-shine transition-all duration-1000"></div>

                            <span className="relative z-10 flex items-center gap-2 group-hover/btn:text-white transition-colors duration-300">
                                Grab Combo <ChevronRight size={14} />
                            </span>
                        </a>
                    </div>
                </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};

export default MasterCourse;
