
import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronRight, Moon, Sun } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    // Dark Mode Logic
    if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setDarkMode(false);
      document.documentElement.classList.remove('dark');
    }

    const calculateScrollProgress = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight;
      const winHeight = window.innerHeight;
      const totalDocScrollLength = docHeight - winHeight;
      const scrollPosition = Math.floor((scrollTop / totalDocScrollLength) * 100);
      
      setScrollProgress(scrollPosition);
      setIsScrolled(scrollTop > 20);
    };

    // Initial calculation
    calculateScrollProgress();

    window.addEventListener('scroll', calculateScrollProgress, { passive: true });
    window.addEventListener('resize', calculateScrollProgress);

    return () => {
      window.removeEventListener('scroll', calculateScrollProgress);
      window.removeEventListener('resize', calculateScrollProgress);
    };
  }, []);

  const toggleTheme = () => {
    if (darkMode) {
      document.documentElement.classList.remove('dark');
      localStorage.theme = 'light';
      setDarkMode(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.theme = 'dark';
      setDarkMode(true);
    }
  };

  const navLinks = [
    { name: 'Course', href: '#course' },
    { name: 'Benefits', href: '#benefits' },
    { name: 'Calculator', href: '#calculator' },
    { name: 'Reviews', href: '#reviews' },
  ];

  return (
    <>
      {/* Scroll Progress Line - Fixed at very top */}
      <div className="fixed top-0 left-0 w-full h-[3px] bg-transparent z-[60] pointer-events-none">
        <div 
          className="h-full bg-gradient-to-r from-royal-500 via-gold-400 to-turquoise-400 shadow-[0_0_15px_rgba(14,165,233,0.6)] transition-all duration-150 ease-out rounded-r-full"
          style={{ width: `${scrollProgress}%` }}
        ></div>
      </div>

      <nav className={`fixed w-full z-50 transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1) border-b ${isScrolled ? 'glass-nav py-3 border-slate-200/50 dark:border-slate-800/50' : 'bg-transparent py-6 border-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <a href="#" className="text-2xl md:text-3xl font-display font-bold tracking-tighter text-slate-900 dark:text-white group transition-transform duration-300 hover:scale-105 origin-left will-change-transform">
                ITC<span className="text-turquoise-500 group-hover:text-gold-500 transition-colors duration-300">.</span>
              </a>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  className="text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors tracking-wide relative after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-[-4px] after:left-0 after:bg-gradient-to-r after:from-royal-600 after:to-turquoise-500 after:origin-bottom-right after:transition-transform after:duration-300 after:cubic-bezier(0.4, 0, 0.2, 1) hover:after:scale-x-100 hover:after:origin-bottom-left"
                >
                  {link.name}
                </a>
              ))}
              
              {/* Dark Mode Toggle */}
              <button 
                onClick={toggleTheme}
                className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-all duration-300 hover:scale-110 hover:rotate-12 active:scale-90 hover:shadow-lg hover:shadow-slate-200/50 dark:hover:shadow-slate-900/50"
                aria-label="Toggle Dark Mode"
              >
                {darkMode ? <Sun size={20} className="text-gold-400" /> : <Moon size={20} />}
              </button>

              <a href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20am%20interested%20in%20the%20ITC%20Master%20Course" target="_blank" rel="noreferrer" className="group relative px-6 py-2.5 rounded-full overflow-hidden bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-lg transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:shadow-[0_10px_25px_-5px_rgba(14,165,233,0.5)] hover:scale-[1.05] hover:-translate-y-0.5 active:scale-95 inline-flex items-center will-change-transform">
                 <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-royal-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                 <div className="absolute top-0 -left-[100%] w-1/2 h-full bg-white/20 -skew-x-[20deg] group-hover:animate-shine"></div>
                 <span className="relative flex items-center gap-2 text-xs font-bold uppercase tracking-widest group-hover:text-white transition-colors">
                    Enroll Now <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform duration-300" />
                 </span>
              </a>
            </div>

            <div className="md:hidden flex items-center gap-4">
              <button 
                onClick={toggleTheme}
                className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-all duration-300 hover:scale-110 active:scale-95"
              >
                {darkMode ? <Sun size={20} className="text-gold-400" /> : <Moon size={20} />}
              </button>

              <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-slate-900 dark:text-white hover:text-royal-600 transition-all duration-300 p-2 hover:scale-110 active:scale-95"
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden glass-nav absolute w-full border-b border-slate-100 dark:border-slate-800 animate-fade-in-up origin-top">
            <div className="px-4 pt-2 pb-8 space-y-2">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="block px-4 py-4 text-base font-medium text-slate-700 dark:text-slate-200 hover:text-royal-600 dark:hover:text-royal-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-xl transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:translate-x-2 hover:scale-[1.02]"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
               <div className="pt-4 px-4">
                  <a href="https://t.me/ITCadmin?text=Hi%20Admin%2C%20I%20am%20interested%20in%20the%20ITC%20Master%20Course" target="_blank" rel="noreferrer" className="block w-full text-center bg-gradient-to-r from-royal-600 to-purple-600 text-white px-6 py-3.5 rounded-xl text-sm font-bold tracking-widest shadow-lg active:scale-95 transition-all duration-300 hover:shadow-royal-500/30 hover:scale-[1.02] hover:shadow-[0_8px_20px_-4px_rgba(14,165,233,0.4)]">
                    ENROLL NOW
                  </a>
               </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
};

export default Navbar;
