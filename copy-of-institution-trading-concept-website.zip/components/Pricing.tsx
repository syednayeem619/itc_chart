
import React from 'react';
import { CheckCircle2, ChevronRight } from 'lucide-react';
import { PRICING } from '../constants';

const Pricing: React.FC = () => {
  const getTelegramLink = (tierName: string, price: string) => {
    let message = '';
    if (tierName === 'Basic') {
        message = `Hi Admin, I am interested in the ITC Master Course`;
    } else if (tierName === 'Pro') {
        message = `Hi Admin, I am interested in the ITC Pro Plan`;
    } else if (tierName === 'Mentorship') {
        message = `Hi Admin, I am interested in the ITC Mentorship Program`;
    } else {
        message = `Hi Admin, I am interested in the ${tierName} plan`;
    }
    return `https://t.me/ITCadmin?text=${encodeURIComponent(message)}`;
  };

  return (
    <section id="pricing" className="py-20 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="text-gold-500 font-bold tracking-widest text-xs uppercase mb-4 block">Invest in Yourself</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6">
            Select Your <span className="italic text-gray-500">Tier</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          {PRICING.map((tier) => (
            <div 
              key={tier.name} 
              className={`relative p-8 rounded-2xl border transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1) will-change-transform ${
                tier.highlighted 
                  ? 'bg-white/5 border-gold-500/50 md:-mt-8 md:mb-8 shadow-2xl shadow-gold-500/10 z-10 scale-105 hover:scale-[1.08] hover:-translate-y-3 hover:shadow-[0_40px_80px_-20px_rgba(234,179,8,0.3)]' 
                  : 'bg-transparent border-white/10 hover:border-white/30 grayscale hover:grayscale-0 hover:bg-white/5 hover:shadow-[0_25px_50px_-12px_rgba(255,255,255,0.1)] hover:-translate-y-2 hover:scale-[1.03]'
              }`}
            >
              {tier.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gold-500 text-black text-xs font-bold px-4 py-1 rounded-full uppercase tracking-widest shadow-lg shadow-gold-500/40 hover:scale-110 hover:-translate-y-0.5 transition-all duration-300 cursor-default">
                  Most Popular
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-xl font-serif text-white mb-2 group-hover:text-gold-200 transition-colors">{tier.name}</h3>
                <div className="text-4xl font-bold text-white mb-2 transform transition-transform duration-300 group-hover:scale-110 inline-block origin-center">{tier.price}</div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">One-time payment</p>
              </div>

              <ul className="space-y-4 mb-8">
                {tier.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-gray-300 transition-all duration-300 hover:text-white hover:translate-x-2 cursor-default">
                    <CheckCircle2 size={16} className={`shrink-0 mt-0.5 transition-colors duration-300 ${tier.highlighted ? 'text-gold-500 group-hover:text-gold-400' : 'text-gray-600 group-hover:text-gold-400'}`} />
                    {feature}
                  </li>
                ))}
              </ul>

              <a 
                href={getTelegramLink(tier.name, tier.price)}
                target="_blank"
                rel="noreferrer"
                className={`group/btn relative block w-full py-4 rounded-xl text-xs font-bold uppercase tracking-widest transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1) hover:scale-[1.05] hover:-translate-y-1 active:scale-95 shadow-lg text-center overflow-hidden hover:shadow-[0_0_50px_rgba(34,197,94,0.8)] ${
                tier.highlighted 
                  ? 'bg-gold-500 text-black shadow-gold-500/30' 
                  : 'bg-white/5 text-white shadow-white/10'
              }`}>
                {/* Radioactive Green Hover Layer */}
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300 ease-out"></div>
                
                {/* Shimmer */}
                <div className="absolute top-0 -left-[100%] w-full h-full bg-gradient-to-r from-transparent via-white/40 to-transparent transform -skew-x-12 group-hover/btn:animate-shine transition-all duration-1000"></div>
                
                <span className="relative z-10 flex items-center justify-center gap-2 group-hover/btn:text-white transition-colors duration-300">
                    {tier.cta} <ChevronRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                </span>
              </a>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
            <p className="text-gray-500 text-sm">
                *Trading involves substantial risk and is not suitable for every investor. 
                <br />Past performance is not indicative of future results.
            </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
