import React, { useState, useEffect, useRef } from 'react';
import { TrendingUp, AlertCircle, Info, Calculator, X } from 'lucide-react';

const ROICalculator: React.FC = () => {
  const [capital, setCapital] = useState(50000);
  const [winRate, setWinRate] = useState(70);
  const [riskReward, setRiskReward] = useState(3);
  const [riskPerTrade, setRiskPerTrade] = useState(2);
  const [tradesPerMonth, setTradesPerMonth] = useState(7);
  
  const [monthlyReturn, setMonthlyReturn] = useState(0);
  const [annualPercent, setAnnualPercent] = useState(0);
  
  // State for managing which info tooltip is open
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);

  // Core Calculation Logic
  useEffect(() => {
    const riskAmount = capital * (riskPerTrade / 100);
    const avgWin = riskAmount * riskReward;
    const avgLoss = riskAmount;
    
    const winRateDecimal = winRate / 100;
    const lossRateDecimal = 1 - winRateDecimal;
    const expectedValuePerTrade = (winRateDecimal * avgWin) - (lossRateDecimal * avgLoss);
    
    const monthly = expectedValuePerTrade * tradesPerMonth;
    const annual = capital > 0 ? ((monthly * 12) / capital) * 100 : 0;

    setMonthlyReturn(Math.floor(monthly));
    setAnnualPercent(Math.floor(annual));
  }, [capital, winRate, riskReward, riskPerTrade, tradesPerMonth]);

  // Close tooltips when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (tooltipRef.current && !tooltipRef.current.contains(event.target as Node)) {
        setActiveTooltip(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const isProfitable = monthlyReturn >= 0;
  const resultColor = isProfitable ? 'text-green-400' : 'text-red-400';
  const borderColor = isProfitable ? 'border-green-500/30' : 'border-red-500/30';

  const getPercent = (value: number, min: number, max: number) => {
    return ((value - min) / (max - min)) * 100;
  };

  const toggleTooltip = (id: string) => {
    setActiveTooltip(activeTooltip === id ? null : id);
  };

  return (
    <section id="calculator" className="py-8 bg-slate-50 dark:bg-slate-950 relative overflow-hidden transition-colors duration-500 cubic-bezier(0.4, 0, 0.2, 1)">
      <style>{`
        .custom-range {
          -webkit-appearance: none;
          width: 100%;
          background: transparent;
        }
        .custom-range::-webkit-slider-thumb {
          -webkit-appearance: none;
          height: 16px;
          width: 16px;
          border-radius: 50%; /* Round */
          background: #0f172a; /* Slate 900 (Black-ish) */
          cursor: grab;
          margin-top: -6px;
          box-shadow: 0 0 0 2px white, 0 4px 6px rgba(0,0,0,0.3);
          transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), background-color 0.2s, box-shadow 0.2s;
        }
        .custom-range:active::-webkit-slider-thumb {
          cursor: grabbing;
          transform: scale(1.3);
          background: #0ea5e9; /* Royal 500 */
          box-shadow: 0 0 0 4px rgba(14, 165, 233, 0.3);
        }
        .dark .custom-range::-webkit-slider-thumb {
            background: #f8fafc;
            box-shadow: 0 0 0 2px #0f172a, 0 4px 6px rgba(0,0,0,0.5);
        }
        .custom-range::-webkit-slider-thumb:hover {
          transform: scale(1.2);
          box-shadow: 0 0 0 4px rgba(255, 255, 255, 0.4);
        }
        .custom-range::-moz-range-thumb {
          height: 16px;
          width: 16px;
          border-radius: 50%;
          background: #0f172a;
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 4px 6px rgba(0,0,0,0.3);
          transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .custom-range::-moz-range-thumb:hover {
            transform: scale(1.2);
        }
        .custom-range::-webkit-slider-runnable-track {
          width: 100%;
          height: 4px;
          cursor: pointer;
          background: transparent;
        }
      `}</style>

      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
        <div className="absolute top-1/4 left-0 w-64 h-64 bg-royal-600 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-1/4 right-0 w-64 h-64 bg-turquoise-500 rounded-full blur-[100px]"></div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-royal-600 dark:text-royal-400 text-xs font-bold uppercase tracking-widest mb-2 shadow-sm hover:shadow-[0_10px_20px_-5px_rgba(14,165,233,0.2)] hover:scale-105 hover:-translate-y-0.5 transition-all cursor-default">
            <Calculator size={14} /> Calculate Your Potential
          </div>
          <h2 className="text-2xl md:text-3xl font-display font-bold text-slate-900 dark:text-white">
            See the Power of <span className="text-transparent bg-clip-text bg-gradient-to-r from-royal-600 to-turquoise-500 dark:from-royal-400 dark:to-turquoise-400">Risk Management</span>
          </h2>
        </div>

        {/* Main Card */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl shadow-slate-200/50 dark:shadow-slate-950/50 border border-slate-100 dark:border-slate-800 transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1) hover:shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] hover:-translate-y-2 hover:scale-[1.005] will-change-transform" ref={tooltipRef}>
          <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[450px]">
            
            {/* Input Section */}
            <div className="lg:col-span-7 p-6 space-y-5 bg-white dark:bg-slate-900 flex flex-col justify-center rounded-t-3xl lg:rounded-l-3xl lg:rounded-tr-none relative z-20 transition-colors duration-300">
                
                {/* Initial Capital */}
                <div className="group">
                    <label className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 group-hover:text-royal-600 dark:group-hover:text-royal-400 transition-colors">
                        Initial Capital 
                        <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-slate-900 dark:text-white font-mono group-hover:bg-royal-50 dark:group-hover:bg-royal-900/30 transition-colors">₹{capital.toLocaleString()}</span>
                    </label>
                    <div className="relative h-3 flex items-center">
                        <div className="absolute w-full h-1 bg-slate-100 dark:bg-slate-800 rounded-full"></div>
                        <div className="absolute h-1 bg-royal-500 rounded-full transition-all duration-150" style={{ width: `${getPercent(capital, 10000, 1000000)}%` }}></div>
                        <input 
                            type="range" min="10000" max="1000000" step="5000" 
                            value={capital} onChange={(e) => setCapital(Number(e.target.value))}
                            className="custom-range relative z-10"
                        />
                    </div>
                </div>

                {/* Win Rate with Tooltip */}
                <div className="group relative">
                    <div className="flex justify-between items-center mb-1.5">
                        <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 group-hover:text-turquoise-600 dark:group-hover:text-turquoise-400 transition-colors cursor-pointer" onClick={() => toggleTooltip('winrate')}>
                            Win Rate 
                            <button className="text-slate-400 hover:text-royal-600 transition-colors p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full"><Info size={12} /></button>
                        </label>
                        <span className={`px-2 py-0.5 rounded font-bold font-mono text-xs transition-all ${winRate >= 50 ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400' : 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400'}`}>
                            {winRate}%
                        </span>
                    </div>

                    {/* Win Rate Explanation Tooltip */}
                    {activeTooltip === 'winrate' && (
                        <div className="absolute bottom-full left-0 mb-3 w-72 bg-slate-900 text-white text-xs p-4 rounded-xl shadow-2xl z-50 border border-slate-700 animate-fade-in-up ring-4 ring-black/5 origin-bottom-left">
                            <div className="flex justify-between items-start mb-3 border-b border-slate-700 pb-2">
                                <strong className="text-turquoise-400 text-sm">What is Win Rate?</strong>
                                <button onClick={() => setActiveTooltip(null)} className="p-1 hover:bg-slate-800 rounded transition-colors"><X size={12} /></button>
                            </div>
                            <div className="space-y-2 text-slate-300">
                                <p>It's simply how many trades you win out of 10.</p>
                                <div className="bg-slate-800 p-2 rounded-lg border border-slate-700">
                                    <p className="font-bold text-white mb-1">Example (10 Trades):</p>
                                    <ul className="space-y-1">
                                        <li className="flex items-center gap-2 text-green-400"><span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span> 6 Winning Trades</li>
                                        <li className="flex items-center gap-2 text-red-400"><span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span> 4 Losing Trades</li>
                                    </ul>
                                    <p className="mt-2 text-right font-mono text-white">= 60% Win Rate</p>
                                </div>
                            </div>
                        </div>
                    )}

                    <div className="relative h-3 flex items-center">
                        <div className="absolute w-full h-1 bg-slate-100 dark:bg-slate-800 rounded-full"></div>
                        <div 
                            className={`absolute h-1 rounded-full transition-all duration-150 ${winRate >= 50 ? 'bg-green-500' : 'bg-orange-400'}`} 
                            style={{ width: `${getPercent(winRate, 0, 100)}%` }}
                        ></div>
                        <input 
                            type="range" min="0" max="100" step="5" 
                            value={winRate} onChange={(e) => setWinRate(Number(e.target.value))}
                            className="custom-range relative z-10"
                        />
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4 items-end">
                    {/* Risk Reward */}
                    <div className="group relative -ml-1 -mr-1">
                         <div className="bg-white dark:bg-slate-800 rounded-lg shadow-[0_8px_20px_rgb(0,0,0,0.1)] dark:shadow-[0_8px_20px_rgb(0,0,0,0.3)] border-l-4 border-royal-500 p-3 scale-100 transform transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:shadow-lg hover:-translate-y-1 hover:scale-[1.04] relative z-10">
                            <label className="flex items-center gap-1 text-[10px] font-bold text-royal-600 dark:text-royal-400 uppercase tracking-wider mb-1 cursor-pointer group-hover:text-royal-500" onClick={() => toggleTooltip('rr')}>
                                Risk:Reward
                                <Info size={10} className="text-royal-400" />
                            </label>

                            {/* RR Explanation Tooltip */}
                            {activeTooltip === 'rr' && (
                                <div className="absolute bottom-full left-0 mb-3 w-72 bg-slate-900 text-white text-xs p-4 rounded-xl shadow-2xl z-50 border border-slate-700 animate-fade-in-up ring-4 ring-black/5">
                                    <div className="flex justify-between items-start mb-3 border-b border-slate-700 pb-2">
                                        <strong className="text-turquoise-400 text-sm">Risk vs Reward Ratio</strong>
                                        <button onClick={() => setActiveTooltip(null)} className="p-1 hover:bg-slate-800 rounded transition-colors"><X size={12} /></button>
                                    </div>
                                    <div className="text-slate-300 space-y-3">
                                        <p>This is the secret to profitability. It means for every <span className="text-red-400">₹1</span> you risk losing, you aim to make <span className="text-green-400">₹3</span> profit.</p>
                                        <div className="bg-slate-800 p-2 rounded-lg border border-slate-700">
                                            <p className="font-bold text-white mb-1 text-[11px] uppercase tracking-wider">Why 1:3 is powerful:</p>
                                            <p className="leading-relaxed">
                                                Even if you lose 5 trades and win only 5, you still make a huge profit because your wins are <span className="text-gold-400 font-bold">3x bigger</span> than your losses!
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div className="relative">
                                <select 
                                    value={riskReward} onChange={(e) => setRiskReward(Number(e.target.value))}
                                    className="w-full bg-transparent font-bold text-xl text-slate-800 dark:text-white focus:outline-none cursor-pointer appearance-none hover:text-royal-600 dark:hover:text-royal-400 transition-colors"
                                >
                                    <option value="1">1:1</option>
                                    <option value="2">1:2</option>
                                    <option value="3">1:3</option>
                                    <option value="4">1:4</option>
                                </select>
                                <p className="text-[10px] text-slate-400 font-medium">
                                    {riskReward === 1 ? "(Balanced)" : riskReward === 2 ? "(Standard)" : riskReward === 3 ? "(High Growth)" : "(Aggressive)"}
                                </p>
                                <TrendingUp size={16} className="absolute right-0 top-1 text-royal-400 pointer-events-none opacity-50" />
                            </div>
                         </div>
                    </div>

                    {/* Trades Per Month */}
                    <div className="group">
                         <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 group-hover:text-royal-600 dark:group-hover:text-royal-400 transition-colors">Trades / Month</label>
                         <input 
                            type="number" value={tradesPerMonth} onChange={(e) => setTradesPerMonth(Number(e.target.value))}
                            className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold text-slate-700 dark:text-white focus:ring-2 focus:ring-royal-500 focus:border-transparent outline-none transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:bg-white dark:hover:bg-slate-800/80 hover:shadow-md hover:scale-[1.02] text-sm"
                         />
                    </div>
                </div>
                 
                {/* Risk Per Trade with Tooltip */}
                <div className="group relative">
                    <div className="flex justify-between items-center mb-1.5">
                         <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 group-hover:text-red-500 transition-colors cursor-pointer" onClick={() => toggleTooltip('risk')}>
                            Risk Per Trade 
                            <button className="text-slate-400 hover:text-royal-600 transition-colors p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full"><Info size={12} /></button>
                        </label>
                        <span className="bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-2 py-0.5 rounded text-xs font-mono group-hover:bg-red-100 dark:group-hover:bg-red-900/50 transition-colors">{riskPerTrade}%</span>
                    </div>

                    {/* Risk Per Trade Explanation Tooltip */}
                    {activeTooltip === 'risk' && (
                        <div className="absolute bottom-full left-0 mb-3 w-72 bg-slate-900 text-white text-xs p-4 rounded-xl shadow-2xl z-50 border border-slate-700 animate-fade-in-up ring-4 ring-black/5">
                            <div className="flex justify-between items-start mb-3 border-b border-slate-700 pb-2">
                                <strong className="text-red-400 text-sm">Risk Per Trade</strong>
                                <button onClick={() => setActiveTooltip(null)} className="p-1 hover:bg-slate-800 rounded transition-colors"><X size={12} /></button>
                            </div>
                            <div className="text-slate-300 space-y-3">
                                <p>This is the % of your total capital you lose if a single trade hits your Stop Loss.</p>
                                <div className="bg-slate-800 p-2 rounded-lg border border-slate-700">
                                    <p className="font-bold text-white mb-1 text-[11px] uppercase tracking-wider">Why only 1-2%?</p>
                                    <p className="leading-relaxed">
                                        If you risk <span className="text-red-400 font-bold">5%</span>, losing 4 trades wipes out 20% of your account!
                                        If you risk <span className="text-green-400 font-bold">1%</span>, you can survive a 10-trade losing streak easily.
                                    </p>
                                </div>
                            </div>
                        </div>
                    )}

                    <div className="relative h-3 flex items-center">
                        <div className="absolute w-full h-1 bg-slate-100 dark:bg-slate-800 rounded-full"></div>
                        <div className="absolute h-1 bg-red-400 rounded-full transition-all duration-150" style={{ width: `${getPercent(riskPerTrade, 0.5, 5)}%` }}></div>
                         <input 
                            type="range" min="0.5" max="5" step="0.5" 
                            value={riskPerTrade} onChange={(e) => setRiskPerTrade(Number(e.target.value))}
                            className="custom-range relative z-10"
                        />
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 text-right">Recommended: 1-2%</p>
                </div>

            </div>

            {/* Results Section */}
            <div className={`lg:col-span-5 p-6 text-white flex flex-col justify-center relative transition-colors duration-500 rounded-b-3xl lg:rounded-r-3xl lg:rounded-bl-none ${isProfitable ? 'bg-slate-900' : 'bg-slate-900'}`}>
                
                {/* Dynamic Background Glow (Clipped within absolute container) */}
                <div className="absolute inset-0 overflow-hidden rounded-b-3xl lg:rounded-r-3xl lg:rounded-bl-none pointer-events-none">
                     <div className={`absolute top-0 right-0 w-64 h-64 rounded-full blur-[80px] opacity-30 transition-colors duration-1000 ${isProfitable ? 'bg-green-500' : 'bg-red-500'}`}></div>
                     <div className={`absolute bottom-0 left-0 w-48 h-48 rounded-full blur-[80px] opacity-30 transition-colors duration-1000 ${isProfitable ? 'bg-turquoise-500' : 'bg-orange-500'}`}></div>
                </div>
                
                <div className="relative z-10 space-y-5">
                    
                    <div className="space-y-3">
                        <div className="group p-5 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:scale-[1.03] hover:-translate-y-1 hover:shadow-xl cursor-default">
                            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1 group-hover:text-white transition-colors">Expected Monthly Return</p>
                            <div className={`text-3xl md:text-4xl font-bold transition-all duration-300 group-hover:scale-105 origin-left ${resultColor}`}>
                                {monthlyReturn >= 0 ? '+' : '-'}₹{Math.abs(monthlyReturn).toLocaleString()}
                            </div>
                        </div>

                        <div className="relative p-5 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:scale-[1.03] hover:-translate-y-1 hover:shadow-xl cursor-default group">
                            <div className="flex items-center gap-2 mb-1">
                                <p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider group-hover:text-white transition-colors">Projected Annual ROI</p>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); toggleTooltip('annual'); }} 
                                    className="text-slate-500 hover:text-white transition-colors p-1 hover:bg-white/10 rounded-full hover:scale-110"
                                    aria-label="Show info"
                                >
                                    <Info size={12} />
                                </button>
                            </div>

                            {/* Annual ROI Tooltip */}
                            {activeTooltip === 'annual' && (
                                <div className="absolute bottom-full left-0 mb-3 w-64 bg-slate-900 text-white text-xs p-4 rounded-xl shadow-2xl z-50 border border-slate-700 animate-fade-in-up ring-4 ring-black/5">
                                     <div className="flex justify-between items-start mb-3 border-b border-slate-700 pb-2">
                                        <strong className="text-gold-400 text-sm">Annual Projection</strong>
                                        <button onClick={(e) => { e.stopPropagation(); setActiveTooltip(null); }} className="p-1 hover:bg-slate-800 rounded transition-colors"><X size={12} /></button>
                                    </div>
                                    <div className="text-slate-300 space-y-2">
                                        <p>Calculated as <span className="font-mono text-white">Monthly Return × 12</span>.</p>
                                        <p>This is a simple linear projection. It does <strong className="text-white">not</strong> account for compounding (re-investing profits), so your actual potential returns could be higher.</p>
                                    </div>
                                </div>
                            )}

                            <div className={`text-2xl font-bold transition-all duration-300 group-hover:scale-105 origin-left ${isProfitable ? 'text-gold-400' : 'text-red-400'}`}>
                                {annualPercent}%
                            </div>
                            <p className="text-[10px] text-slate-500 mt-1">Compounding effects not included.</p>
                        </div>
                    </div>

                    {/* Educational Banner */}
                    <div className={`rounded-xl p-3 border ${borderColor} ${isProfitable ? 'bg-green-500/10' : 'bg-red-500/10'} backdrop-blur-sm transition-all duration-300 hover:scale-[1.02] hover:shadow-lg`}>
                        <div className="flex gap-3 items-center">
                            {isProfitable ? <TrendingUp className="text-green-400 shrink-0 w-5 h-5 animate-bounce" /> : <AlertCircle className="text-red-400 shrink-0 w-5 h-5 animate-pulse" />}
                            <div>
                                <h4 className={`font-bold text-xs mb-0.5 ${isProfitable ? 'text-green-300' : 'text-red-300'}`}>
                                    {isProfitable ? "Profitable Edge! 🚀" : "Adjustment Needed ⚠️"}
                                </h4>
                                <p className="text-[10px] text-slate-300 leading-tight">
                                    Even with <span className="text-white font-bold">50% accuracy</span> you can be profitable with proper RR. 
                                    <span className="text-gold-400 font-bold block mt-0.5">ITC strategies have nearly 70% accuracy.</span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="pt-2 border-t border-white/10 text-center">
                        <p className="text-[10px] text-slate-500">
                            *Theoretical projection based on mathematical expectancy.
                        </p>
                    </div>
                </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};

export default ROICalculator;