import React from 'react';
import { Bell, TrendingUp, Users, MessageCircle, Shield } from 'lucide-react';

const TelegramCommunity: React.FC = () => {
  return (
    <section className="py-24 bg-gradient-to-br from-royal-600 to-purple-700 relative overflow-hidden text-white">
      {/* Abstract Shapes */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10">
         <div className="absolute top-20 left-20 w-64 h-64 bg-white rounded-full blur-[100px] animate-float"></div>
         <div className="absolute bottom-20 right-20 w-80 h-80 bg-turquoise-400 rounded-full blur-[120px] animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
          {/* Content */}
          <div className="flex flex-col items-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-xs font-bold uppercase tracking-widest mb-6 backdrop-blur-sm hover:bg-white/20 transition-all duration-300 hover:scale-105 cursor-default hover:shadow-[0_0_15px_rgba(255,255,255,0.3)] hover:-translate-y-0.5">
              <Users size={12} /> Community Access
            </div>
            
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 leading-tight hover:scale-[1.02] transition-transform duration-500 cursor-default">
              Join 12,000+ Traders <br /> in Our Free Community
            </h2>
            
            <p className="text-royal-100 text-lg mb-10 leading-relaxed max-w-2xl mx-auto">
              Real-time market updates, chart analysis, and a supportive environment. No spam, no paid tips - purely educational.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10 w-full max-w-2xl">
                {[
                    { icon: <TrendingUp size={20} />, text: "Daily Chart Analysis" },
                    { icon: <Bell size={20} />, text: "Live Trade Ideas" },
                    { icon: <Shield size={20} />, text: "Real-Time Updates" },
                    { icon: <MessageCircle size={20} />, text: "Peer Support" },
                ].map((item, idx) => (
                    <div key={idx} className="group flex items-center gap-3 bg-white/5 p-4 rounded-lg border border-white/10 hover:bg-white/15 hover:border-white/30 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) justify-center sm:justify-start hover:-translate-y-1 hover:scale-[1.02] hover:shadow-lg hover:shadow-purple-500/10 cursor-default will-change-transform backdrop-blur-sm">
                        <div className="text-turquoise-400 group-hover:scale-125 transition-transform duration-300 group-hover:rotate-6 group-hover:text-turquoise-300">{item.icon}</div>
                        <span className="font-medium group-hover:text-white transition-colors group-hover:translate-x-1 duration-300">{item.text}</span>
                    </div>
                ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                 <a 
                    href="https://t.me/itc_charts"
                    target="_blank"
                    rel="noreferrer"
                    className="px-8 py-4 bg-white text-royal-600 font-bold rounded-xl shadow-lg hover:shadow-[0_0_40px_rgba(255,255,255,0.4)] hover:scale-105 hover:-translate-y-1 transition-all duration-300 flex items-center justify-center gap-2 group active:scale-95 cubic-bezier(0.4, 0, 0.2, 1) will-change-transform"
                 >
                    <MessageCircle size={20} className="group-hover:scale-110 group-hover:rotate-12 transition-transform duration-300" /> 
                    Join Free Telegram Channel
                 </a>
                 <div className="px-6 py-4 flex items-center justify-center gap-2 text-sm text-royal-200 cursor-default hover:text-white transition-colors hover:scale-105 transform duration-300">
                    <Shield size={16} /> No spam, Pure Education
                 </div>
            </div>
          </div>

      </div>
    </section>
  );
};

export default TelegramCommunity;