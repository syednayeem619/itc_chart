import React, { useRef } from 'react';
import { TESTIMONIALS } from '../constants';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';

const Testimonials: React.FC = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { current } = scrollRef;
      const scrollAmount = 350; // Approx width of card + gap
      if (direction === 'left') {
        current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
      } else {
        current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
    }
  };

  return (
    <section id="reviews" className="py-16 bg-slate-900 text-white relative overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4 hover:scale-[1.02] transition-transform duration-500 origin-center cursor-default">
            What Our Students Say
          </h2>
          <p className="text-slate-400">100% True and Genuine Reviews from our community.</p>
        </div>

        <div className="relative">
            {/* Left Button */}
            <button 
                onClick={() => scroll('left')}
                className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-6 z-20 bg-royal-600/90 hover:bg-royal-500 text-white p-3 rounded-full shadow-xl backdrop-blur-sm transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hidden md:flex items-center justify-center border border-white/10 hover:scale-110 hover:-translate-y-1 hover:shadow-[0_0_25px_rgba(14,165,233,0.6)] active:scale-95"
                aria-label="Scroll Left"
            >
                <ChevronLeft size={24} />
            </button>
            
            {/* Right Button */}
            <button 
                onClick={() => scroll('right')}
                className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-6 z-20 bg-royal-600/90 hover:bg-royal-500 text-white p-3 rounded-full shadow-xl backdrop-blur-sm transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hidden md:flex items-center justify-center border border-white/10 hover:scale-110 hover:-translate-y-1 hover:shadow-[0_0_25px_rgba(14,165,233,0.6)] active:scale-95"
                aria-label="Scroll Right"
            >
                <ChevronRight size={24} />
            </button>

            {/* Scroll Container */}
            <div 
                ref={scrollRef}
                className="flex overflow-x-auto pb-12 pt-4 gap-4 snap-x snap-mandatory scrollbar-hide scroll-smooth px-4 md:px-0"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
                {TESTIMONIALS.map((t) => (
                    <div 
                        key={t.id} 
                        className="snap-center shrink-0 w-[85vw] sm:w-[400px] bg-white/5 border border-white/10 p-8 rounded-2xl hover:bg-white/10 transition-all duration-400 cubic-bezier(0.34, 1.56, 0.64, 1) relative flex flex-col shadow-lg hover:shadow-[0_25px_50px_-12px_rgba(14,165,233,0.25)] hover:-translate-y-3 hover:scale-[1.02] group will-change-transform backdrop-blur-sm"
                    >
                        <Quote className="text-gold-500 mb-4 opacity-50 group-hover:opacity-100 group-hover:scale-110 group-hover:rotate-12 transition-all duration-300" size={32} />
                        <p className="text-slate-300 text-sm leading-relaxed mb-6 flex-1 italic group-hover:text-white transition-colors duration-300">"{t.content}"</p>
                        
                        <div className="flex items-center justify-between border-t border-white/10 pt-4 mt-auto group-hover:border-white/20 transition-colors">
                            <div>
                                <h4 className="font-bold text-sm text-white group-hover:text-gold-300 transition-colors">{t.name}</h4>
                                <div className="flex gap-1 mt-1">
                                    {[...Array(5)].map((_, i) => (
                                        <Star key={i} size={12} className="fill-gold-500 text-gold-500 group-hover:scale-110 transition-transform" style={{ transitionDelay: `${i * 50}ms` }} />
                                    ))}
                                </div>
                            </div>
                            <div className="flex items-center gap-1 bg-green-500/20 text-green-400 text-[10px] px-2 py-1 rounded border border-green-500/30 font-bold uppercase tracking-wider group-hover:bg-green-500/30 transition-all duration-300 hover:scale-105 hover:border-green-500/60 cursor-default">
                                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                                Verified
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            
            {/* Mobile Navigation Hint */}
            <div className="flex justify-center gap-2 mt-2 md:hidden opacity-60">
                <div className="text-xs text-slate-400 font-medium flex items-center gap-2 animate-pulse">
                    Swipe for more <ChevronRight size={14} />
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;