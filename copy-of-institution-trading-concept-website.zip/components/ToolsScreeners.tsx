import React from 'react';
import { Filter, BarChart2, ArrowRight, Zap } from 'lucide-react';

const ToolsScreeners: React.FC = () => {
  const tools = [
    {
      title: "Multiple Screeners",
      description: "Filter stocks by technical & fundamental criteria. Find demand/supply zone candidates instantly across NSE/BSE.",
      icon: <Filter className="w-8 h-8 text-royal-500" />,
      features: ["NSE/BSE Coverage", "Zone Detection", "Trend Filters"]
    },
    {
      title: "Custom Indicators",
      description: "TradingView-compatible indicators that help automate zone marking and alert you to RSI divergences.",
      icon: <BarChart2 className="w-8 h-8 text-turquoise-500" />,
      features: ["Auto Zone Marking", "RSI Divergence", "Alert System"]
    }
  ];

  return (
    <section className="py-16 bg-white dark:bg-slate-950 relative overflow-hidden transition-colors duration-500 cubic-bezier(0.4, 0, 0.2, 1)">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-slate-50 dark:bg-slate-900 skew-x-12 opacity-50 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-royal-50 dark:bg-royal-900/30 text-royal-600 dark:text-royal-400 text-xs font-bold uppercase tracking-widest mb-4 hover:shadow-[0_4px_12px_rgba(14,165,233,0.2)] hover:scale-105 hover:-translate-y-0.5 transition-all duration-300 cursor-default">
            <Zap size={12} className="fill-royal-600 dark:fill-royal-400" /> Included Bonuses
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 dark:text-white mb-4">
            Exclusive <span className="text-royal-600 dark:text-royal-400 relative inline-block hover:scale-105 transition-transform duration-300 origin-left">Trading Tools</span>
          </h2>
          <p className="text-slate-500 dark:text-slate-400 max-w-2xl mx-auto">
            Stop guessing. Use the same professional tools we use to find and execute high-probability trades daily.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
          {tools.map((tool, index) => (
            <div 
              key={index}
              className="group bg-white dark:bg-slate-900 p-8 rounded-2xl shadow-lg border border-slate-100 dark:border-slate-800 transition-all duration-400 cubic-bezier(0.34, 1.56, 0.64, 1) hover:border-royal-200 dark:hover:border-royal-800 hover:shadow-[0_30px_60px_-15px_rgba(14,165,233,0.15)] hover:-translate-y-3 hover:scale-[1.02] will-change-transform relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-royal-50/0 to-royal-50/50 dark:from-royal-900/0 dark:to-royal-900/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
              
              <div className="mb-6 p-4 bg-slate-50 dark:bg-slate-800 rounded-xl inline-block group-hover:bg-royal-50 dark:group-hover:bg-royal-900/30 transition-all duration-300 shadow-sm group-hover:scale-110 group-hover:rotate-6 transform relative z-10 group-hover:shadow-lg">
                {tool.icon}
              </div>
              
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3 group-hover:text-royal-700 dark:group-hover:text-royal-400 transition-colors relative z-10">{tool.title}</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-6 leading-relaxed group-hover:text-slate-600 dark:group-hover:text-slate-300 transition-colors relative z-10">
                {tool.description}
              </p>

              <div className="space-y-3 pt-6 border-t border-slate-50 dark:border-slate-800 relative z-10">
                {tool.features.map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300 font-medium transition-all duration-300 hover:translate-x-2 hover:text-royal-600 dark:hover:text-royal-400">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.5)] group-hover:scale-150 transition-transform"></div>
                    {feature}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="inline-flex items-center gap-2 text-royal-600 dark:text-royal-400 font-bold hover:text-royal-700 dark:hover:text-royal-300 transition-all duration-300 group hover:scale-105 hover:-translate-y-0.5">
            Access Premium Tools with Course <ArrowRight className="group-hover:translate-x-1 transition-transform duration-300" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default ToolsScreeners;