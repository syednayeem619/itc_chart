import React, { useState } from 'react';
import { ArrowRight, RefreshCw, Book, Award } from 'lucide-react';
import { QUIZ_QUESTIONS } from '../constants';

const TradingQuiz: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (optionIndex: number) => {
    if (optionIndex === QUIZ_QUESTIONS[currentQuestion].correctAnswerIndex) {
      setScore(score + 1);
    }
    
    if (currentQuestion < QUIZ_QUESTIONS.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResult(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
  };

  const isHighScore = score >= 3;

  return (
    <section className="py-24 bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white relative overflow-hidden transition-colors duration-500">
      {/* Background patterns */}
      <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4 hover:scale-[1.02] transition-transform duration-500">
            Test Your Trading Knowledge
          </h2>
          <p className="text-purple-200">Are you ready for Institutional Trading? Take the 5-question challenge.</p>
        </div>

        <div className="bg-white text-slate-900 rounded-2xl shadow-2xl overflow-hidden min-h-[400px] flex flex-col transition-all duration-500 hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.5)] hover:scale-[1.01] will-change-transform">
          
          {!showResult ? (
            <div className="flex-1 flex flex-col p-8 md:p-12">
              {/* Progress Bar */}
              <div className="w-full bg-slate-100 h-2 rounded-full mb-8 overflow-hidden">
                <div 
                    className="bg-gradient-to-r from-purple-500 to-indigo-500 h-2 rounded-full transition-all duration-700 ease-out shadow-[0_0_10px_rgba(168,85,247,0.5)]"
                    style={{ width: `${((currentQuestion + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
                ></div>
              </div>

              <div className="flex-1 flex flex-col justify-center animate-fade-in-up" key={currentQuestion}>
                <span className="text-purple-600 font-bold uppercase tracking-widest text-xs mb-4">
                    Question {currentQuestion + 1} of {QUIZ_QUESTIONS.length}
                </span>
                <h3 className="text-2xl md:text-3xl font-bold mb-8 leading-snug">
                    {QUIZ_QUESTIONS[currentQuestion].question}
                </h3>
                
                <div className="grid grid-cols-1 gap-3">
                    {QUIZ_QUESTIONS[currentQuestion].options.map((option, idx) => (
                        <button
                            key={idx}
                            onClick={() => handleAnswer(idx)}
                            className="p-4 rounded-xl border-2 border-slate-100 hover:border-purple-500 hover:bg-purple-50 text-left transition-all duration-300 group flex items-center justify-between hover:scale-[1.02] hover:-translate-y-1 hover:shadow-lg active:scale-95 cubic-bezier(0.4, 0, 0.2, 1)"
                        >
                            <span className="font-medium text-slate-700 group-hover:text-purple-900 transition-colors">{option}</span>
                            <ArrowRight size={16} className="opacity-0 group-hover:opacity-100 text-purple-600 transition-all duration-300 transform -translate-x-4 group-hover:translate-x-0" />
                        </button>
                    ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col p-8 md:p-12 items-center justify-center text-center animate-fade-in-up">
               <div className={`w-24 h-24 rounded-full flex items-center justify-center mb-6 shadow-xl animate-float ${isHighScore ? 'bg-gold-100 text-gold-600 shadow-gold-500/20' : 'bg-turquoise-100 text-turquoise-600 shadow-turquoise-500/20'}`}>
                  {isHighScore ? <Award size={48} /> : <Book size={48} />}
               </div>
               
               <h3 className="text-3xl font-bold mb-2">
                  You Scored {score} / {QUIZ_QUESTIONS.length}
               </h3>
               
               <p className="text-slate-500 mb-8 max-w-md mx-auto">
                  {isHighScore 
                    ? "Excellent! You have a solid grasp of trading concepts. You are ready to master the institutional edge."
                    : "You're on the right track, but missing some key institutional concepts. We recommend building a strong foundation first."}
               </p>
               
               <div className={`border p-8 rounded-2xl w-full max-w-lg mb-8 shadow-lg transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:scale-[1.03] hover:-translate-y-1 ${isHighScore ? 'bg-gradient-to-br from-royal-50 to-white border-royal-200 hover:shadow-royal-500/20' : 'bg-gradient-to-br from-turquoise-50 to-white border-turquoise-200 hover:shadow-turquoise-500/20'}`}>
                  <div className={`text-xs uppercase font-bold tracking-widest mb-3 ${isHighScore ? 'text-royal-600' : 'text-turquoise-600'}`}>
                      Your Recommendation
                  </div>
                  
                  {isHighScore ? (
                    <>
                        <div className="text-2xl font-bold text-slate-900 mb-2">ITC Master Course</div>
                        <p className="text-slate-600 text-sm mb-6">
                            Since you understand the basics, dive straight into our advanced curriculum to refine your execution and reach profitability.
                        </p>
                        <a href="#course" className="inline-block w-full py-4 bg-gradient-to-r from-royal-600 to-purple-600 text-white font-bold rounded-xl hover:shadow-lg hover:scale-105 hover:shadow-royal-500/30 transition-all duration-300 active:scale-95">
                           Enroll in Master Course
                        </a>
                    </>
                  ) : (
                    <>
                        <div className="text-2xl font-bold text-slate-900 mb-2">Institutional E-Book (Foundation)</div>
                        <p className="text-slate-600 text-sm mb-6">
                            Start with our comprehensive E-Book to clear your concepts on Demand & Supply zones before investing in the full mentorship.
                        </p>
                        <div className="flex flex-col gap-3">
                             <a href="#course" className="inline-block w-full py-3 bg-turquoise-500 text-white font-bold rounded-xl hover:bg-turquoise-600 hover:shadow-lg hover:shadow-turquoise-500/30 hover:scale-105 transition-all duration-300 active:scale-95">
                                Get E-Book for ₹499
                            </a>
                            <span className="text-xs text-slate-400">OR</span>
                            <a href="#course" className="text-royal-600 text-sm font-bold hover:underline hover:text-royal-700 transition-colors">
                                Get the Combo (Best Value)
                            </a>
                        </div>
                    </>
                  )}
               </div>

               <button onClick={resetQuiz} className="text-slate-400 hover:text-slate-600 font-medium text-sm flex items-center gap-2 transition-all hover:rotate-180 hover:text-royal-500 group">
                  <RefreshCw size={14} className="group-hover:rotate-180 transition-transform duration-500" /> <span className="hover:rotate-[-180deg] inline-block transition-transform">Retake Quiz</span>
               </button>
            </div>
          )}

        </div>
      </div>
    </section>
  );
};

export default TradingQuiz;