
import React, { useState, useEffect } from 'react';
import { Quote, ChevronLeft, ChevronRight } from 'lucide-react';

const QUOTES = [
  { 
    category: "The Power of an Edge", 
    text: "Success in the markets hinges on a sustainable edge—a repeatable statistical advantage unknown or underutilized by the majority." 
  },
  { 
    category: "The Power of an Edge", 
    text: "An edge is not a secret strategy; it is the disciplined execution of a superior methodology." 
  },
  { 
    category: "The Power of an Edge", 
    text: "The true function of a trader is to identify and consistently exploit their quantifiable edge." 
  },
  { 
    category: "Executing with High Probability", 
    text: "Trading is a game of managing uncertainty. We prioritize high probability setups to ensure that positive expectancy is maintained over time." 
  },
  { 
    category: "Executing with High Probability", 
    text: "The mark of a professional trader is the patience to wait for high probability entries, filtering out noise and low-quality action." 
  },
  { 
    category: "Executing with High Probability", 
    text: "Risk management is simplified when your focus is strictly on high probability scenarios that align with your systemic criteria." 
  },
  { 
    category: "The Mandate for Continuous Learning", 
    text: "Market mastery is not a destination, but a process. Continuous learning is the non-negotiable cost of staying relevant and profitable." 
  },
  { 
    category: "The Mandate for Continuous Learning", 
    text: "The greatest variable in your trading performance is your commitment to self-assessment and learning from every trade." 
  },
  { 
    category: "The Mandate for Continuous Learning", 
    text: "To adapt to evolving market dynamics, one must commit to continuous learning, viewing mistakes not as failures, but as essential data points for refinement." 
  }
];

const getGradient = (category: string) => {
  switch(category) {
    case "The Power of an Edge":
      // Royal/Blue Theme
      return "from-blue-50 via-white to-indigo-50 dark:from-blue-950/40 dark:via-slate-900 dark:to-indigo-950/20";
    case "Executing with High Probability":
      // Emerald/Teal Theme
      return "from-emerald-50 via-white to-teal-50 dark:from-emerald-950/40 dark:via-slate-900 dark:to-teal-950/20";
    case "The Mandate for Continuous Learning":
      // Amber/Gold Theme
      return "from-amber-50 via-white to-orange-50 dark:from-amber-950/40 dark:via-slate-900 dark:to-orange-950/20";
    default:
      return "from-slate-50 via-white to-gray-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800/30";
  }
};

const TradingQuotesSlider: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % QUOTES.length);
    }, 12000); // 12 seconds per quote

    return () => clearInterval(interval);
  }, [isPaused]);

  const next = () => setCurrentIndex((prev) => (prev + 1) % QUOTES.length);
  const prev = () => setCurrentIndex((prev) => (prev - 1 + QUOTES.length) % QUOTES.length);

  // Swipe Handlers
  const onTouchStart = (e: React.TouchEvent) => {
    setIsPaused(true);
    setTouchEnd(null); 
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe) next();
    if (isRightSwipe) prev();

    // Resume auto-play after interaction
    // Small delay to prevent immediate jump if timer was close
    setTimeout(() => setIsPaused(false), 2000);
  };

  const currentCategory = QUOTES[currentIndex].category;
  const gradientClass = getGradient(currentCategory);

  return (
    <section className="py-8 bg-slate-50 dark:bg-slate-950 transition-colors duration-500 cubic-bezier(0.4, 0, 0.2, 1)">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          className="relative bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-slate-100 dark:border-slate-800 overflow-hidden min-h-[220px] flex items-center transition-all duration-300 hover:shadow-xl hover:border-royal-100 dark:hover:border-royal-900/30 group will-change-transform touch-pan-y"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >
          {/* Dynamic Background Layer */}
          <div className={`absolute inset-0 bg-gradient-to-br ${gradientClass} transition-all duration-1000 ease-in-out`}></div>
          
          {/* Subtle Grain Texture Overlay */}
          <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05] bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] pointer-events-none"></div>

          {/* Navigation Buttons */}
          <div className="absolute left-2 sm:left-4 z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button 
              onClick={prev} 
              className="p-2 rounded-full bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm border border-slate-200/50 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-700 text-slate-500 hover:text-royal-600 dark:hover:text-royal-400 transition-all hover:scale-110 active:scale-95 shadow-sm"
              aria-label="Previous Quote"
            >
              <ChevronLeft size={20} />
            </button>
          </div>
          <div className="absolute right-2 sm:right-4 z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button 
              onClick={next} 
              className="p-2 rounded-full bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm border border-slate-200/50 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-700 text-slate-500 hover:text-royal-600 dark:hover:text-royal-400 transition-all hover:scale-110 active:scale-95 shadow-sm"
              aria-label="Next Quote"
            >
              <ChevronRight size={20} />
            </button>
          </div>

          {/* Slider Content */}
          <div className="w-full h-full relative z-10 overflow-hidden py-8 px-8 sm:px-20">
             <div 
               className="flex transition-transform duration-700 ease-[cubic-bezier(0.25,0.1,0.25,1)] w-full"
               style={{ transform: `translateX(-${currentIndex * 100}%)` }}
             >
                {QUOTES.map((quote, idx) => (
                  <div key={idx} className="w-full flex-shrink-0 flex flex-col items-center justify-center text-center px-2 select-none">
                      <div className="inline-flex items-center gap-2 mb-4 animate-fade-in-up">
                        <Quote size={14} className="text-royal-400/60 dark:text-royal-400/40 rotate-180" />
                        <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">{quote.category}</span>
                        <Quote size={14} className="text-royal-400/60 dark:text-royal-400/40" />
                      </div>
                      <p className="text-lg md:text-xl font-serif text-slate-800 dark:text-slate-100 leading-relaxed italic max-w-3xl mx-auto selection:bg-royal-100 dark:selection:bg-royal-900/30 drop-shadow-sm">
                        "{quote.text}"
                      </p>
                  </div>
                ))}
             </div>
          </div>

          {/* Dots Indicator */}
          <div className="absolute bottom-4 left-0 w-full flex justify-center gap-1.5 z-20 pointer-events-none">
            {QUOTES.map((_, idx) => (
              <div 
                key={idx}
                className={`h-1 rounded-full transition-all duration-500 ${currentIndex === idx ? 'w-6 bg-slate-800 dark:bg-white' : 'w-1 bg-slate-300 dark:bg-slate-700'}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TradingQuotesSlider;
