import React, { useState } from 'react';
import { Share2, Upload, CheckCircle2, Loader2, Copy } from 'lucide-react';

const WhatsAppVerifier: React.FC = () => {
  const [step, setStep] = useState(1);
  const [uploads, setUploads] = useState<(string | null)[]>([null, null, null]);
  const [isVerifying, setIsVerifying] = useState(false);
  const [discountCode, setDiscountCode] = useState<string | null>(null);

  const generateLink = () => {
    const uniqueId = Math.random().toString(36).substring(7).toUpperCase();
    const link = `https://itctrading.com/c/?ref=${uniqueId}`;
    const message = encodeURIComponent(`🚀 Found an amazing trading course!\n\nLearn Demand & Supply Zones for NSE/BSE trading\n✅ 70%+ Win Rate Setups\n✅ Only ₹4,999 (Limited Time)\n\nCheck it out: ${link}\n\n#TradingCourse #NSE #BSE`);
    window.open(`https://wa.me/?text=${message}`, '_blank');
    setStep(2);
  };

  const handleUpload = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const url = URL.createObjectURL(e.target.files[0]);
      const newUploads = [...uploads];
      newUploads[index] = url;
      setUploads(newUploads);
    }
  };

  const verify = () => {
    setIsVerifying(true);
    // Simulate backend verification
    setTimeout(() => {
      setIsVerifying(false);
      setDiscountCode(`SHARE100-${Math.random().toString(36).substring(2, 7).toUpperCase()}`);
      setStep(3);
    }, 2500);
  };

  return (
    <section className="py-20 bg-slate-50 dark:bg-slate-950 transition-colors duration-500 cubic-bezier(0.4, 0, 0.2, 1)">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-slate-900 dark:to-slate-800 rounded-3xl border border-orange-200 dark:border-slate-700 p-8 shadow-lg relative overflow-hidden transition-all duration-500 hover:shadow-2xl hover:shadow-orange-500/10 hover:-translate-y-2 hover:scale-[1.01] cubic-bezier(0.4, 0, 0.2, 1) will-change-transform">
          <div className="absolute top-0 right-0 w-40 h-40 bg-orange-300 dark:bg-orange-500/10 rounded-full blur-[80px] opacity-30 pointer-events-none"></div>
          
          <div className="relative z-10 text-center mb-10">
            <div className="inline-block bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest mb-4 animate-pulse shadow-lg shadow-orange-500/30 hover:scale-110 transition-transform cursor-default">
                Instant ₹100 OFF
            </div>
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Share & Save!</h2>
            <p className="text-slate-600 dark:text-slate-400">Share in 3 WhatsApp Groups → Get Discount Code Instantly</p>
          </div>

          {/* Steps Visualization */}
          <div className="flex justify-between max-w-xs mx-auto mb-10 relative">
             <div className="absolute top-1/2 left-0 w-full h-1 bg-orange-200 dark:bg-slate-700 -z-0 -translate-y-1/2"></div>
             {[1, 2, 3].map((s) => (
                 <div key={s} className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-500 ${step >= s ? 'bg-orange-500 text-white scale-125 shadow-md' : 'bg-orange-200 dark:bg-slate-700 text-orange-800 dark:text-slate-400'}`}>
                     {s}
                 </div>
             ))}
          </div>

          {step === 1 && (
             <div className="text-center animate-fade-in-up">
                <button 
                    onClick={generateLink}
                    className="bg-[#25D366] hover:bg-[#128C7E] text-white px-8 py-4 rounded-xl font-bold shadow-lg hover:shadow-[#25D366]/40 hover:scale-105 hover:-translate-y-1 transition-all duration-300 flex items-center gap-3 mx-auto active:scale-95 cubic-bezier(0.4, 0, 0.2, 1)"
                >
                    <Share2 size={20} className="animate-bounce" /> Share to WhatsApp Groups
                </button>
                <p className="mt-4 text-sm text-slate-500 dark:text-slate-400">Click to generate your unique tracking link</p>
             </div>
          )}

          {step === 2 && (
            <div className="animate-fade-in-up">
                <h3 className="text-center font-bold text-slate-800 dark:text-slate-200 mb-6">Upload 3 Screenshots</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                    {uploads.map((url, idx) => (
                        <div key={idx} className="aspect-[9/16] bg-white dark:bg-slate-800 border-2 border-dashed border-orange-300 dark:border-slate-600 rounded-lg flex flex-col items-center justify-center relative overflow-hidden hover:bg-orange-50 dark:hover:bg-slate-700 transition-all duration-300 cursor-pointer hover:scale-[1.03] hover:-translate-y-1 hover:border-orange-500 dark:hover:border-orange-400 group shadow-sm hover:shadow-md">
                            <input 
                                type="file" 
                                className="absolute inset-0 opacity-0 cursor-pointer z-20" 
                                onChange={(e) => handleUpload(idx, e)}
                                accept="image/*"
                            />
                            {url ? (
                                <img src={url} alt="Preview" loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                            ) : (
                                <>
                                    <Upload className="text-orange-400 dark:text-slate-500 mb-2 group-hover:scale-110 group-hover:-translate-y-1 transition-transform duration-300" />
                                    <span className="text-xs text-slate-500 dark:text-slate-400 group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">Group {idx + 1}</span>
                                </>
                            )}
                            {url && <div className="absolute top-2 right-2 bg-green-500 rounded-full p-1 shadow-md z-10 animate-fade-in-up"><CheckCircle2 size={12} className="text-white" /></div>}
                        </div>
                    ))}
                </div>
                <button 
                    onClick={verify}
                    disabled={uploads.some(u => !u) || isVerifying}
                    className="w-full bg-slate-900 dark:bg-white disabled:bg-slate-400 disabled:cursor-not-allowed text-white dark:text-slate-900 py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1) hover:shadow-xl hover:scale-[1.02] hover:-translate-y-1 active:scale-95 disabled:hover:scale-100 disabled:hover:translate-y-0 disabled:shadow-none"
                >
                    {isVerifying ? <Loader2 className="animate-spin" /> : 'Verify & Get Code'}
                </button>
            </div>
          )}

          {step === 3 && discountCode && (
            <div className="text-center animate-fade-in-up">
                <div className="text-6xl mb-4 animate-bounce">🎉</div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">Verified! Here's Your Code</h3>
                
                <div className="bg-white dark:bg-slate-800 border-2 border-dashed border-green-500 p-6 rounded-xl max-w-sm mx-auto mb-6 relative group hover:shadow-xl hover:-translate-y-1 hover:border-green-400 transition-all duration-300 cubic-bezier(0.4, 0, 0.2, 1)">
                    <div className="text-2xl font-mono font-bold text-green-600 dark:text-green-400 tracking-wider group-hover:scale-105 transition-transform">{discountCode}</div>
                    <button className="absolute top-1/2 right-4 -translate-y-1/2 text-slate-400 hover:text-green-600 dark:hover:text-green-400 transition-colors hover:scale-110 hover:rotate-6">
                        <Copy size={20} />
                    </button>
                </div>
                
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Valid for 7 days. Use at checkout.</p>
                <a href="https://t.me/ITCadmin?text=Hi%2C%20I%20have%20verified%20sharing%20and%20got%20a%20discount%20code.%20I%20want%20to%20enroll." target="_blank" rel="noreferrer" className="text-orange-600 dark:text-orange-400 font-bold hover:underline hover:text-orange-700 dark:hover:text-orange-300 transition-colors inline-block hover:scale-105 transform">Use Code Now &rarr;</a>
            </div>
          )}

        </div>
      </div>
    </section>
  );
};

export default WhatsAppVerifier;