
import { Benefit, ChatTrigger, Module, Testimonial, PricingTier, FAQItem, QuizQuestion } from './types';

export const COURSE_MODULES: Module[] = [
  {
    id: '01',
    title: 'Foundation',
    lessons: ['Candlestick Patterns & Psychology', 'Market Structure Basics', 'Institutional vs Retail Trading'],
    duration: 'Approx 1.5 Hours for each video'
  },
  {
    id: '02',
    title: 'Demand & Supply Zones',
    lessons: ['Zone Identification & Marking', 'Buying & Selling Zones', 'Gap Zones & Hidden Zones', 'Zone Strength Evaluation'],
    duration: 'Approx 1.5 Hours for each video'
  },
  {
    id: '03',
    title: 'Multi-Timeframe Analysis',
    lessons: ['Top-Down Approach (HTF to LTF)', 'Timeframe Correlation', 'Confluence for High-Probability Setups'],
    duration: 'Approx 1.5 Hours for each video'
  },
  {
    id: '04',
    title: 'Advanced Concepts',
    lessons: ['Achievement Zones & Confirmation Entry', 'AVD Trend Analysis', 'Premium & Discount with Fibonacci', 'Implicit/Explicit Knowledge'],
    duration: 'Approx 1.5 Hours for each video'
  },
  {
    id: '05',
    title: 'Execution & Risk',
    lessons: ['Entry Styles (Aggressive vs Conservative)', 'Position Sizing & 1-2% Risk Rule', 'Trading Psychology & Discipline', 'Identifying Trap Zones'],
    duration: 'Approx 1.5 Hours for each video'
  },
  {
    id: '06',
    title: 'Tools & Screening',
    lessons: ['Technical & Fundamental Screeners', 'Sector Analysis for NSE', 'Using Indicators (RSI Divergence)'],
    duration: 'Approx 1.5 Hours for each video'
  }
];

export const BENEFITS: Benefit[] = [
  {
    id: 1,
    title: "Demand & Supply Mastery",
    description: "Master institutional-level zone identification. Learn proximal/distal zones, gap zones, and strength evaluation.",
    icon: "🎯",
    colorGradient: "from-yellow-100 to-yellow-200"
  },
  {
    id: 2,
    title: "India-Focused",
    description: "Focus on NSE & BSE Stocks.",
    icon: "🇮🇳",
    colorGradient: "from-orange-100 to-orange-200"
  },
  {
    id: 3,
    title: "High Probability Setups",
    description: "Learn to identify 70%+ win rate setups using institutional logic.",
    icon: "📈",
    colorGradient: "from-green-100 to-green-200"
  },
  {
    id: 4,
    title: "Trading Psychology",
    description: "Build the mindset for consistency: discipline, patience, emotional control.",
    icon: "🧠",
    colorGradient: "from-purple-100 to-purple-200"
  },
  {
    id: 5,
    title: "Exclusive Telegram Group",
    description: "Get 2 months of premium group access unlocked immediately after watching the full course.",
    icon: "📱",
    colorGradient: "from-blue-100 to-blue-200"
  },
  {
    id: 6,
    title: "Affordable Education",
    description: "World-class trading education at ₹4,999 - less than one day's profit target.",
    icon: "💰",
    colorGradient: "from-teal-100 to-teal-200"
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: "Student Review",
    content: "Just wanted to say a big thank you for creating such an amazing trading course! The way you explain things makes even the tough stuff easy to understand. I am very lucky that I bought this course.",
    rating: 5
  },
  {
    id: 2,
    name: "Student Review",
    content: "I have seen your video till 10th but Already i got so much confidence, I made almost double profit in 1 Hr. Thank You for this Excellent Course 😍",
    rating: 5
  },
  {
    id: 3,
    name: "Student Review",
    content: "Aray yaar 100% pesa vasul. Mene abhi 6 class dekha hai our mene Jo stock pick Kiya hai 7 stock mene 4 stock ne to tagda return diya",
    rating: 5
  },
  {
    id: 4,
    name: "Student Review",
    content: "Assalam alaikum bhai. Alhamdulillah aaj course complete Kiya. Business ki waja se time bahot kam milta hai. But itc se best course kahi nhi milega ye baat mai confirm krta hu.",
    rating: 5
  },
  {
    id: 5,
    name: "Student Review",
    content: "With very cheap price valuable knowledge",
    rating: 5
  },
  {
    id: 6,
    name: "Student Review",
    content: "Ji Bhai koi doubt ni hai bahut behtarin tarike se samjhaya gaya hai. Samjhane wale ki tarif hai.",
    rating: 5
  },
  {
    id: 7,
    name: "Student Review",
    content: "Honestly speaking your teaching methodology and chart reading are superb. I will personally recommend you to my circle.",
    rating: 5
  }
];

export const CHAT_TRIGGERS: ChatTrigger[] = [
  {
    keywords: ["price", "cost", "fees", "kitna"],
    response: "The ITC Master Course is ₹4,999. The E-Book is ₹499. 🔥 Best Deal: Get BOTH in the Combo Pack for just ₹5,098 (Save ₹399)! 🎉"
  },
  {
    keywords: ["included", "get", "milega"],
    response: "Course includes: ✅ 13 recorded sessions ✅ 1 year access ✅ Screeners ✅ Indicators ✅ 2 months Telegram group (after watching course). E-Book sold separately or in Combo."
  },
  {
    keywords: ["beginner", "new", "start"],
    response: "Yes! This course is perfect for beginners. We start from basics (candlesticks, market structure) and take you to advanced institutional strategies step by step. 😊"
  },
  {
    keywords: ["telegram", "group", "community"],
    response: "After completing the course, you get 2 months FREE access to our Premium Telegram group where you can discuss charts with like-minded traders! 📱"
  },
  {
    keywords: ["modules", "curriculum", "syllabus"],
    response: "We cover 6 modules: Foundation, Demand & Supply Zones, Multi-Timeframe Analysis, Advanced Concepts, Execution & Risk, Tools & Screening. Each module has detailed lessons! 📚"
  },
  {
    keywords: ["nse", "bse", "indian"],
    response: "Yes! All strategies are specifically designed for NSE/BSE trading with examples using real Indian stocks like TCS, Reliance, HDFC Bank, etc. 🇮🇳"
  },
  {
    keywords: ["win", "rate", "success", "profit"],
    response: "Our strategies focus on identifying 70%+ win rate setups using institutional logic and proper risk management (1-2% per trade). 📈"
  },
  {
    keywords: ["ebook", "book", "pdf"],
    response: "The E-Book (70+ pages) is available for ₹499, or get it with the Master Course in the Combo Pack for ₹5,098 to save money! 📖"
  },
  {
    keywords: ["enroll", "join", "buy", "purchase"],
    response: "Great! To enroll, click the 'Enroll Now' button or message our admin on Telegram: @ITCadmin 🚀"
  },
  {
    keywords: ["contact", "admin"],
    response: "You can reach our admin directly on Telegram: @ITCadmin for enrollment and queries! 📞"
  }
];

export const PRICING: PricingTier[] = [
  {
    name: 'Basic',
    price: '₹4,999',
    features: ['Course Access (1 Year)', 'E-Book Included', '2 Months Telegram Group (After Course)', 'Basic Support'],
    cta: 'Enroll Now',
    highlighted: false
  },
  {
    name: 'Pro',
    price: '₹7,999',
    features: ['Lifetime Course Access', 'E-Book Included', '6 Months Telegram Group (After Course)', 'Priority Support', '1-on-1 Session'],
    cta: 'Go Pro',
    highlighted: true
  },
  {
    name: 'Mentorship',
    price: '₹14,999',
    features: ['Lifetime Access', 'Lifetime Telegram (After Course)', 'Weekly Live Calls', 'Personal Mentorship', 'Trading Journal Review'],
    cta: 'Apply Now',
    highlighted: false
  }
];

export const FAQS: FAQItem[] = [
  {
    question: "What is Institutional Trading Concept (ITC)?",
    answer: "ITC is a pure price action methodology that teaches you to identify where institutions place their pending orders. By understanding demand and supply zones at an institutional level, you can trade alongside the \"smart money\" instead of against them. This approach works on NSE/BSE stocks, indices, and provides directional bias for options trading."
  },
  {
    question: "Is this suitable for beginners?",
    answer: "Absolutely! The course starts from basic candlestick psychology and builds up to advanced multi-timeframe analysis. We focus on one concept at a time with clear examples using Indian stocks. Many of our successful students started with zero trading knowledge."
  },
  {
    question: "How is this different from indicator-based trading?",
    answer: "Indicators lag price action - they show what already happened. ITC teaches you to read raw price movements and identify institutional zones before moves happen. You'll understand WHY the market moves, not just WHAT it's doing."
  },
  {
    question: "Can I use this for intraday trading?",
    answer: "Yes! The ITC concept works across all timeframes. Whether you're a scalper (5-15 min charts), intraday trader (hourly charts), or swing trader (daily charts), the demand-supply principles remain the same."
  },
  {
    question: "Is demand and supply trading reliable in India?",
    answer: "Demand and supply zones are universal principles that work in all markets. Indian markets (NSE/BSE) follow the same institutional logic. Our students successfully apply these strategies to Nifty, Bank Nifty, and individual stocks daily."
  }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "What actually moves the market price?",
    options: ["RSI & MACD Indicators", "News Channels", "Institutional Pending Orders (Demand/Supply)", "Retail Traders Buying"],
    correctAnswerIndex: 2
  },
  {
    id: 2,
    question: "What is the recommended risk per trade for professional consistency?",
    options: ["1-2% of capital", "10-20% of capital", "Whatever I feel confident with", "50% (Go big or go home)"],
    correctAnswerIndex: 0
  },
  {
    id: 3,
    question: "When price leaves a zone explosively, what does it indicate?",
    options: ["Retail Fear", "Market Confusion", "Strong Institutional Imbalance", "Weak Volume"],
    correctAnswerIndex: 2
  },
  {
    id: 4,
    question: "Why do we use Multi-Timeframe Analysis?",
    options: ["To make the chart look complex", "To align higher timeframe bias with lower timeframe entry", "To find more indicators", "It is not necessary"],
    correctAnswerIndex: 1
  },
  {
    id: 5,
    question: "What is a 'Trap' in trading?",
    options: ["A legal issue", "When institutions induce retail traders to enter the wrong side before reversing", "A bad broker", "Low volatility"],
    correctAnswerIndex: 1
  }
];
