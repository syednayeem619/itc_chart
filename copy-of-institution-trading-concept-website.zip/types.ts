export interface Testimonial {
  id: number;
  name: string;
  content: string;
  rating: number;
}

export interface Module {
  id: string;
  title: string;
  lessons: string[];
  duration: string;
}

export interface Benefit {
  id: number;
  title: string;
  description: string;
  icon: string; // Using emoji as string for simplicity based on prompt
  colorGradient: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: number;
  actionLink?: string;
  actionLabel?: string;
}

export interface ChatTrigger {
  keywords: string[];
  response: string;
}

export interface ScreenshotUpload {
  id: string;
  file: File | null;
  previewUrl: string | null;
  verified: boolean;
}

export interface PricingTier {
  name: string;
  price: string;
  features: string[];
  cta: string;
  highlighted: boolean;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswerIndex: number;
}